# Спецификация модулей `philosophy_graph` — по собранному дереву

Составлено из готовой сборки: 130 модулей, 22206 строк.
Не замысел, а описание того, что есть, — поэтому расходиться с
действительностью ей нечем. Пересобирается программой `tools/maps/gen_spec2.mjs`
после каждой сборки.

## Как это строится

```
tools/build/split.mjs <дерево> <исходник> <раскладка> <карта>   разбивка
tools/build/delegate.mjs <дерево> static                        атрибуты страницы
tools/build/delegate.mjs <дерево> dyn                           атрибуты генераторов
tools/build/rig.mjs <дерево>                                    оснастка приборов
tools/build/prune_imports.mjs <дерево>                          призрачные ввозы
tools/build/prune_exports.mjs <дерево>                          лишние вывозы
tools/build/split_css.mjs <дерево>                              стили по главам
```

Источник — **пропатченная одностраничная версия** (`philosophy_graph_v3.html`):
она же служит эталоном приёмки. Всякая новая возможность вносится в неё, а в
сборку приезжает разбивкой — по одной реализации на возможность.

**Раскладка задаётся именами, а не строками** (`assign_names.json`, 697 имён).
Номера строк сдвигаются от любой вставки, и по замеру тридцать чужих
сущностей молча уезжали в соседние модули. Имя, которого в раскладке нет,
**останавливает сборку** с перечнем — новая сущность требует явного решения.


## Пространства имён

| Имя | Что держит |
|---|---|
| `DATA` | шесть наборов базы и девять производных указателей; заполняется при запуске |
| `S` | изменяемое состояние и отложенные ячейки — всё, что либо меняется из чужого модуля (в том числе **из разметки**), либо не может быть вычислено при ввозе |
| `MET` | метрики, к которым обращаются по имени |
| `VIEWS` | генераторы окон, к которым обращаются по имени |

Три последних заменили `window[имя]`, который в модулях не работает вовсе.


## Модули

| Модуль | Строк | Вывозит | Ввозит из |
|---|---|---|---|
| `boot.js` | 327 | 1 | 67 |
| `main.js` | 136 | 0 | 125 |
| `modules/boot-defs.js` | 62 | 2 | 8 |
| `modules/core/api.js` | 90 | 3 | 1 |
| `modules/core/base-cells.js` | 19 | 0 | 1 |
| `modules/core/events.js` | 66 | 2 | 0 |
| `modules/core/graph-index.js` | 238 | 17 | 1 |
| `modules/core/link-facts.js` | 86 | 11 | 2 |
| `modules/core/long-task.js` | 121 | 3 | 0 |
| `modules/core/ns.js` | 33 | 4 | 0 |
| `modules/core/perms.js` | 28 | 3 | 0 |
| `modules/core/ready.js` | 15 | 2 | 0 |
| `modules/core/relation-types.js` | 59 | 5 | 2 |
| `modules/core/search.js` | 68 | 4 | 3 |
| `modules/core/session.js` | 23 | 4 | 1 |
| `modules/core/time.js` | 13 | 2 | 0 |
| `modules/core/visibility.js` | 13 | 2 | 1 |
| `modules/data/backend.js` | 123 | 4 | 5 |
| `modules/data/commit-draft.js` | 37 | 1 | 0 |
| `modules/data/load.js` | 9 | 1 | 1 |
| `modules/data/mutate.js` | 89 | 1 | 6 |
| `modules/data/remote.js` | 186 | 6 | 7 |
| `modules/data/save.js` | 87 | 8 | 2 |
| `modules/dead.js` | 86 | 6 | 5 |
| `modules/filters/beyond-filter.js` | 21 | 2 | 2 |
| `modules/filters/chains.js` | 273 | 3 | 4 |
| `modules/filters/filters.js` | 443 | 2 | 13 |
| `modules/graph/click-actions.js` | 201 | 2 | 8 |
| `modules/graph/graph-data.js` | 121 | 10 | 9 |
| `modules/graph/graph-selection.js` | 61 | 3 | 3 |
| `modules/metrics/by-link-type.js` | 116 | 3 | 2 |
| `modules/metrics/concept-dynamics.js` | 224 | 4 | 2 |
| `modules/metrics/descriptions.js` | 478 | 1 | 3 |
| `modules/metrics/format.js` | 32 | 2 | 2 |
| `modules/metrics/generativity.js` | 110 | 3 | 1 |
| `modules/metrics/graph-cache.js` | 129 | 2 | 3 |
| `modules/metrics/link-indexes.js` | 122 | 1 | 5 |
| `modules/metrics/network.js` | 950 | 18 | 4 |
| `modules/metrics/philosopher.js` | 308 | 6 | 2 |
| `modules/metrics/philosophical.js` | 1130 | 14 | 4 |
| `modules/metrics/rankings.js` | 141 | 4 | 3 |
| `modules/metrics/scope-reset.js` | 64 | 1 | 12 |
| `modules/metrics/scope-select.js` | 99 | 6 | 2 |
| `modules/metrics/scope.js` | 149 | 7 | 8 |
| `modules/metrics/similarity-concepts.js` | 493 | 22 | 3 |
| `modules/metrics/similarity-philosophers.js` | 166 | 7 | 2 |
| `modules/metrics/tension-cache.js` | 13 | 1 | 1 |
| `modules/metrics/tradition-bridging.js` | 89 | 3 | 2 |
| `modules/modal/assembly.js` | 56 | 3 | 2 |
| `modules/modal/auth.js` | 247 | 4 | 9 |
| `modules/modal/commits.js` | 444 | 19 | 7 |
| `modules/modal/concept-view.js` | 442 | 2 | 10 |
| `modules/modal/conflict.js` | 88 | 5 | 7 |
| `modules/modal/connection-edit.js` | 289 | 5 | 13 |
| `modules/modal/connection-view.js` | 421 | 5 | 12 |
| `modules/modal/context.js` | 11 | 1 | 0 |
| `modules/modal/core.js` | 159 | 5 | 10 |
| `modules/modal/descriptions.js` | 162 | 6 | 0 |
| `modules/modal/dirty.js` | 116 | 1 | 6 |
| `modules/modal/edit-forms.js` | 297 | 2 | 12 |
| `modules/modal/edit-rights.js` | 61 | 4 | 4 |
| `modules/modal/entry.js` | 124 | 12 | 10 |
| `modules/modal/forms.js` | 212 | 12 | 3 |
| `modules/modal/history.js` | 114 | 4 | 5 |
| `modules/modal/integrity.js` | 265 | 7 | 7 |
| `modules/modal/persist.js` | 467 | 6 | 14 |
| `modules/modal/philosopher-view.js` | 668 | 1 | 15 |
| `modules/modal/profile-concept.js` | 182 | 4 | 8 |
| `modules/modal/profile-philosopher.js` | 121 | 2 | 8 |
| `modules/modal/search.js` | 43 | 3 | 1 |
| `modules/modal/security.js` | 116 | 4 | 4 |
| `modules/modal/selection-list.js` | 334 | 13 | 8 |
| `modules/modal/users.js` | 97 | 7 | 3 |
| `modules/paths/analysis.js` | 74 | 2 | 7 |
| `modules/paths/chronology.js` | 175 | 6 | 4 |
| `modules/paths/path-descriptions.js` | 180 | 3 | 9 |
| `modules/paths/path-ui.js` | 423 | 5 | 11 |
| `modules/paths/shortest-path.js` | 203 | 1 | 5 |
| `modules/render/canvas-core.js` | 38 | 7 | 2 |
| `modules/render/d3-layer.js` | 106 | 9 | 6 |
| `modules/render/draw-link.js` | 73 | 6 | 6 |
| `modules/render/geometry.js` | 105 | 4 | 4 |
| `modules/render/grouping.js` | 115 | 3 | 6 |
| `modules/render/interactions.js` | 318 | 4 | 19 |
| `modules/render/loop.js` | 20 | 2 | 0 |
| `modules/render/metric-visualization.js` | 371 | 3 | 5 |
| `modules/render/picking.js` | 95 | 3 | 8 |
| `modules/render/render-state.js` | 47 | 10 | 3 |
| `modules/render/scene.js` | 353 | 8 | 12 |
| `modules/render/selection.js` | 261 | 7 | 10 |
| `modules/render/similarity-overlay.js` | 256 | 5 | 9 |
| `modules/render/simulation.js` | 128 | 8 | 10 |
| `modules/render/tooltip-el.js` | 7 | 1 | 0 |
| `modules/state/edit.js` | 15 | 1 | 1 |
| `modules/state/filters.js` | 20 | 3 | 2 |
| `modules/state/metrics-scope.js` | 13 | 0 | 1 |
| `modules/state/paths.js` | 18 | 0 | 2 |
| `modules/state/render.js` | 137 | 11 | 4 |
| `modules/state/stats.js` | 33 | 0 | 1 |
| `modules/stats/coverage.js` | 66 | 3 | 6 |
| `modules/stats/modal.js` | 269 | 9 | 19 |
| `modules/stats/observations.js` | 223 | 5 | 6 |
| `modules/stats/results.js` | 416 | 8 | 5 |
| `modules/stats/run.js` | 128 | 1 | 3 |
| `modules/stats/views/advanced.js` | 275 | 10 | 4 |
| `modules/stats/views/comparison.js` | 508 | 12 | 11 |
| `modules/stats/views/network.js` | 223 | 9 | 4 |
| `modules/stats/views/philosopher.js` | 171 | 4 | 6 |
| `modules/stats/views/philosophical.js` | 474 | 12 | 8 |
| `modules/stats/views/rankings.js` | 141 | 2 | 5 |
| `modules/ui/about.js` | 102 | 3 | 1 |
| `modules/ui/actions-byname.js` | 20 | 0 | 2 |
| `modules/ui/actions-dyn.js` | 187 | 0 | 38 |
| `modules/ui/actions-static.js` | 140 | 0 | 26 |
| `modules/ui/actions.js` | 27 | 3 | 0 |
| `modules/ui/delegation.js` | 70 | 1 | 1 |
| `modules/ui/export.js` | 138 | 2 | 11 |
| `modules/ui/hint.js` | 60 | 4 | 1 |
| `modules/ui/legend.js` | 392 | 25 | 7 |
| `modules/ui/link-state.js` | 282 | 6 | 17 |
| `modules/ui/notifications.js` | 103 | 8 | 3 |
| `modules/ui/panels.js` | 40 | 2 | 0 |
| `modules/ui/search-legend.js` | 141 | 6 | 16 |
| `modules/ui/search-link.js` | 135 | 5 | 11 |
| `modules/ui/search-philosopher.js` | 98 | 6 | 6 |
| `modules/util/color.js` | 23 | 1 | 0 |
| `modules/util/html.js` | 95 | 11 | 0 |
| `modules/util/philosopher-label.js` | 40 | 5 | 3 |
| `modules/util/ru.js` | 49 | 3 | 0 |
| `modules/widgets/custom-select.js` | 103 | 4 | 5 |

## Состав, вывоз и ввоз по модулям


### `boot.js`

Строк 327.

**Вывозит:** `boot`

**Ввозит:**

- из `./modules/core/ns.js`: `DATA`, `S`
- из `./modules/data/load.js`: `loadData`
- из `./modules/core/ready.js`: `onReady`, `onLoad`
- из `./modules/core/graph-index.js`: `buildConceptToRubrics`
- из `./modules/core/graph-index.js`: `buildRubricsIndex`
- из `./modules/core/graph-index.js`: `buildPhilosopherTraditions`
- из `./modules/stats/modal.js`: `installStatsModalDismiss`
- из `./modules/stats/modal.js`: `installStatsEscape`
- из `./modules/stats/results.js`: `restoreMetricLayoutMode`
- из `./modules/ui/search-legend.js`: `installLegendSearchDismiss`
- из `./modules/render/interactions.js`: `installNodeDrag`
- из `./modules/render/simulation.js`: `installSimulationTick`
- из `./modules/render/simulation.js`: `installSimulationStatsEnd`
- из `./modules/render/interactions.js`: `installNodeHover`
- из `./modules/render/interactions.js`: `installLinkHover`
- из `./modules/render/grouping.js`: `buildGroupPositions`
- из `./modules/render/grouping.js`: `installResize`
- из `./modules/data/save.js`: `installUnsavedGuard`
- из `./modules/modal/search.js`: `installModalSearchDismiss`
- из `./modules/boot-defs.js`: `installOverlayDismiss`
- из `./modules/boot-defs.js`: `installModalKeys`
- из `./modules/ui/hint.js`: `installHintOver`
- из `./modules/ui/hint.js`: `installHintOut`
- из `./modules/ui/hint.js`: `installHintOnScroll`
- из `./modules/ui/hint.js`: `installHintOnClick`
- из `./modules/render/simulation.js`: `installSimulationLog`
- из `./modules/ui/legend.js`: `syncLegendWeightsToggle`
- из `./modules/ui/legend.js`: `syncLegendDirectionToggle`
- из `./modules/paths/chronology.js`: `installChronologyToggle`
- из `./modules/paths/chronology.js`: `installChronologyMode`
- из `./modules/paths/chronology.js`: `showChronologyModeIfOn`
- из `./modules/core/api.js`: `detectServerMode`
- из `./modules/core/events.js`: `emit`, `subscribe`
- из `./modules/core/graph-index.js`: `rebuildIndexes`
- из `./modules/core/long-task.js`: `showTemporaryMessage`
- из `./modules/data/remote.js`: `connectLive`, `liveSocket`, `pullGraphSince`
- из `./modules/filters/beyond-filter.js`: `resetBeyondFilter`
- из `./modules/filters/filters.js`: `applyFiltersImmediate`
- из `./modules/metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `./modules/metrics/scope-reset.js`: `invalidateEverythingForScope`
- из `./modules/modal/commits.js`: `revertCommitFromPanel`, `reviewCommitFromPanel`, `showImpact`
- из `./modules/modal/conflict.js`: `showConflict`, `warnRemoteEdit`
- из `./modules/modal/connection-edit.js`: `selectConnectionEditConcept`
- из `./modules/modal/connection-view.js`: `selectConnectionViewConcept`
- из `./modules/modal/core.js`: `modalStack`, `openUniversalModal`
- из `./modules/modal/edit-rights.js`: `refreshEditHints`, `renderAuthControls`
- из `./modules/modal/entry.js`: `closeDetailModal`, `openEditConceptModal`, `openEditConnectionModal`, `showDetailModal`
- из `./modules/modal/forms.js`: `installFootnoteLinks`
- из `./modules/modal/philosopher-view.js`: `makeLegendsEditable`
- из `./modules/modal/users.js`: `banUserFromPanel`, `changeUserRoleFromPanel`
- из `./modules/paths/path-ui.js`: `initPathFinder`
- из `./modules/render/canvas-core.js`: `resizeCanvas`
- из `./modules/render/interactions.js`: `initGraphEventHandlers`
- из `./modules/render/loop.js`: `requestDraw`, `setPainter`
- из `./modules/render/metric-visualization.js`: `saveOriginalRadii`
- из `./modules/render/scene.js`: `draw`, `updateGraphData`
- из `./modules/render/similarity-overlay.js`: `clearSimilarityOverlay`
- из `./modules/state/filters.js`: `pinnedDespiteFilter`
- из `./modules/state/render.js`: `installLayoutPull`, `layoutFromStore`, `storedLayoutComplaint`
- из `./modules/stats/modal.js`: `closeStatsModal`, `loadStatsContent`, `refreshObservationsNav`, `switchStatsView`
- из `./modules/stats/views/comparison.js`: `renderComparison`
- из `./modules/ui/legend.js`: `initFilters`, `markChosenInLegend`, `syncTraditionRows`, `updateFilterStats`
- из `./modules/ui/link-state.js`: `initLinkState`
- из `./modules/ui/notifications.js`: `markNotificationRead`, `refreshUnread`, `renderBell`
- из `./modules/ui/panels.js`: `restorePanelStates`
- из `./modules/widgets/custom-select.js`: `initializeCustomSelects`
- из `./modules/core/graph-index.js`: _ради побочного действия_

**Содержит:** `boot`

### `main.js`

Строк 136.

**Вывозит:** _ничего_

**Ввозит:**

- из `./modules/ui/delegation.js`: `installDelegation`
- из `./boot.js`: `boot`
- из `./modules/boot-defs.js`: _ради побочного действия_
- из `./modules/core/api.js`: _ради побочного действия_
- из `./modules/core/base-cells.js`: _ради побочного действия_
- из `./modules/core/events.js`: _ради побочного действия_
- из `./modules/core/graph-index.js`: _ради побочного действия_
- из `./modules/core/link-facts.js`: _ради побочного действия_
- из `./modules/core/long-task.js`: _ради побочного действия_
- из `./modules/core/perms.js`: _ради побочного действия_
- из `./modules/core/relation-types.js`: _ради побочного действия_
- из `./modules/core/search.js`: _ради побочного действия_
- из `./modules/core/session.js`: _ради побочного действия_
- из `./modules/core/time.js`: _ради побочного действия_
- из `./modules/core/visibility.js`: _ради побочного действия_
- из `./modules/data/backend.js`: _ради побочного действия_
- из `./modules/data/commit-draft.js`: _ради побочного действия_
- из `./modules/data/mutate.js`: _ради побочного действия_
- из `./modules/data/remote.js`: _ради побочного действия_
- из `./modules/data/save.js`: _ради побочного действия_
- из `./modules/dead.js`: _ради побочного действия_
- из `./modules/filters/beyond-filter.js`: _ради побочного действия_
- из `./modules/filters/chains.js`: _ради побочного действия_
- из `./modules/filters/filters.js`: _ради побочного действия_
- из `./modules/graph/click-actions.js`: _ради побочного действия_
- из `./modules/graph/graph-data.js`: _ради побочного действия_
- из `./modules/graph/graph-selection.js`: _ради побочного действия_
- из `./modules/metrics/by-link-type.js`: _ради побочного действия_
- из `./modules/metrics/concept-dynamics.js`: _ради побочного действия_
- из `./modules/metrics/descriptions.js`: _ради побочного действия_
- из `./modules/metrics/format.js`: _ради побочного действия_
- из `./modules/metrics/generativity.js`: _ради побочного действия_
- из `./modules/metrics/graph-cache.js`: _ради побочного действия_
- из `./modules/metrics/link-indexes.js`: _ради побочного действия_
- из `./modules/metrics/network.js`: _ради побочного действия_
- из `./modules/metrics/philosopher.js`: _ради побочного действия_
- из `./modules/metrics/philosophical.js`: _ради побочного действия_
- из `./modules/metrics/rankings.js`: _ради побочного действия_
- из `./modules/metrics/scope-reset.js`: _ради побочного действия_
- из `./modules/metrics/scope-select.js`: _ради побочного действия_
- из `./modules/metrics/scope.js`: _ради побочного действия_
- из `./modules/metrics/similarity-concepts.js`: _ради побочного действия_
- из `./modules/metrics/similarity-philosophers.js`: _ради побочного действия_
- из `./modules/metrics/tension-cache.js`: _ради побочного действия_
- из `./modules/metrics/tradition-bridging.js`: _ради побочного действия_
- из `./modules/modal/assembly.js`: _ради побочного действия_
- из `./modules/modal/auth.js`: _ради побочного действия_
- из `./modules/modal/commits.js`: _ради побочного действия_
- из `./modules/modal/concept-view.js`: _ради побочного действия_
- из `./modules/modal/conflict.js`: _ради побочного действия_
- из `./modules/modal/connection-edit.js`: _ради побочного действия_
- из `./modules/modal/connection-view.js`: _ради побочного действия_
- из `./modules/modal/context.js`: _ради побочного действия_
- из `./modules/modal/core.js`: _ради побочного действия_
- из `./modules/modal/descriptions.js`: _ради побочного действия_
- из `./modules/modal/dirty.js`: _ради побочного действия_
- из `./modules/modal/edit-forms.js`: _ради побочного действия_
- из `./modules/modal/edit-rights.js`: _ради побочного действия_
- из `./modules/modal/entry.js`: _ради побочного действия_
- из `./modules/modal/forms.js`: _ради побочного действия_
- из `./modules/modal/history.js`: _ради побочного действия_
- из `./modules/modal/integrity.js`: _ради побочного действия_
- из `./modules/modal/persist.js`: _ради побочного действия_
- из `./modules/modal/philosopher-view.js`: _ради побочного действия_
- из `./modules/modal/profile-concept.js`: _ради побочного действия_
- из `./modules/modal/profile-philosopher.js`: _ради побочного действия_
- из `./modules/modal/search.js`: _ради побочного действия_
- из `./modules/modal/security.js`: _ради побочного действия_
- из `./modules/modal/selection-list.js`: _ради побочного действия_
- из `./modules/modal/users.js`: _ради побочного действия_
- из `./modules/paths/analysis.js`: _ради побочного действия_
- из `./modules/paths/chronology.js`: _ради побочного действия_
- из `./modules/paths/path-descriptions.js`: _ради побочного действия_
- из `./modules/paths/path-ui.js`: _ради побочного действия_
- из `./modules/paths/shortest-path.js`: _ради побочного действия_
- из `./modules/render/canvas-core.js`: _ради побочного действия_
- из `./modules/render/d3-layer.js`: _ради побочного действия_
- из `./modules/render/draw-link.js`: _ради побочного действия_
- из `./modules/render/geometry.js`: _ради побочного действия_
- из `./modules/render/grouping.js`: _ради побочного действия_
- из `./modules/render/interactions.js`: _ради побочного действия_
- из `./modules/render/loop.js`: _ради побочного действия_
- из `./modules/render/metric-visualization.js`: _ради побочного действия_
- из `./modules/render/picking.js`: _ради побочного действия_
- из `./modules/render/render-state.js`: _ради побочного действия_
- из `./modules/render/scene.js`: _ради побочного действия_
- из `./modules/render/selection.js`: _ради побочного действия_
- из `./modules/render/similarity-overlay.js`: _ради побочного действия_
- из `./modules/render/simulation.js`: _ради побочного действия_
- из `./modules/render/tooltip-el.js`: _ради побочного действия_
- из `./modules/state/edit.js`: _ради побочного действия_
- из `./modules/state/filters.js`: _ради побочного действия_
- из `./modules/state/metrics-scope.js`: _ради побочного действия_
- из `./modules/state/paths.js`: _ради побочного действия_
- из `./modules/state/render.js`: _ради побочного действия_
- из `./modules/state/stats.js`: _ради побочного действия_
- из `./modules/stats/coverage.js`: _ради побочного действия_
- из `./modules/stats/modal.js`: _ради побочного действия_
- из `./modules/stats/observations.js`: _ради побочного действия_
- из `./modules/stats/results.js`: _ради побочного действия_
- из `./modules/stats/run.js`: _ради побочного действия_
- из `./modules/stats/views/advanced.js`: _ради побочного действия_
- из `./modules/stats/views/comparison.js`: _ради побочного действия_
- из `./modules/stats/views/network.js`: _ради побочного действия_
- из `./modules/stats/views/philosopher.js`: _ради побочного действия_
- из `./modules/stats/views/philosophical.js`: _ради побочного действия_
- из `./modules/stats/views/rankings.js`: _ради побочного действия_
- из `./modules/ui/about.js`: _ради побочного действия_
- из `./modules/ui/export.js`: _ради побочного действия_
- из `./modules/ui/hint.js`: _ради побочного действия_
- из `./modules/ui/legend.js`: _ради побочного действия_
- из `./modules/ui/link-state.js`: _ради побочного действия_
- из `./modules/ui/notifications.js`: _ради побочного действия_
- из `./modules/ui/panels.js`: _ради побочного действия_
- из `./modules/ui/search-legend.js`: _ради побочного действия_
- из `./modules/ui/search-link.js`: _ради побочного действия_
- из `./modules/ui/search-philosopher.js`: _ради побочного действия_
- из `./modules/util/color.js`: _ради побочного действия_
- из `./modules/util/html.js`: _ради побочного действия_
- из `./modules/util/philosopher-label.js`: _ради побочного действия_
- из `./modules/util/ru.js`: _ради побочного действия_
- из `./modules/widgets/custom-select.js`: _ради побочного действия_
- из `./modules/ui/actions-byname.js`: _ради побочного действия_
- из `./modules/ui/actions-static.js`: _ради побочного действия_
- из `./modules/ui/actions-dyn.js`: _ради побочного действия_

**Содержит:** _только исполняемый код_

### `modules/boot-defs.js`

Строк 62.

**Вывозит:** `installModalKeys`, `installOverlayDismiss`

**Ввозит:**

- из `./core/ns.js`: `S`
- из `./graph/graph-selection.js`: `cancelGraphSelection`
- из `./modal/core.js`: `closeUniversalModal`, `modalStack`, `popModalState`
- из `./modal/entry.js`: `closeDetailModal`, `closePhilosopherDetailModal`
- из `./modal/profile-concept.js`: `closeConceptProfileModal`
- из `./modal/profile-philosopher.js`: `closePhilosopherProfileModal`
- из `./paths/path-descriptions.js`: `closePathDescriptionsModal`
- из `./ui/about.js`: `closeAboutModal`

**Содержит:** `closeAllModals`, `installModalKeys`, `installOverlayDismiss`

### `modules/core/api.js`

Строк 90.

**Вывозит:** `api`, `detectServerMode`, `serverMode`

**Ввозит:**

- из `./session.js`: `setSessionUser`

**Содержит:** `api`, `detectServerMode`, `readCookie`, `serverMode`

### `modules/core/base-cells.js`

Строк 19.

**Вывозит:** _ничего_

**Ввозит:**

- из `./ns.js`: `S`

**Содержит:** `S._conceptMap`, `S._concepts`, `S._incomingLinks`, `S._outgoingLinks`, `S._philosopherMap`, `S._philosophers`, `S._reflexiveMap`, `S._relations`

### `modules/core/events.js`

Строк 66.

**Вывозит:** `emit`, `subscribe`

**Ввозит:** _ничего_

**Содержит:** `BUS_EVENTS`, `BUS_PHASES`, `busSubscribers`, `emit`, `subscribe`

### `modules/core/graph-index.js`

Строк 238.

**Вывозит:** `buildConceptToRubrics`, `buildPhilosopherTraditions`, `buildRubricsIndex`, `compareConcepts`, `compareLinks`, `comparePhilosophers`, `conceptById`, `linkIsInternal`, `linksByConcept`, `nodesByPhilosopher`, `otherEndColor`, `philosopherByName`, `rebuildIndexes`, `rubricById`, `storedRecord`, `traditionById`, `withoutEmptyOptional`

**Ввозит:**

- из `./ns.js`: `DATA`

**Содержит:** `OMITTED_WHEN_EMPTY`, `buildConceptToRubrics`, `buildIndexes`, `buildPhilosopherTraditions`, `buildRubricsIndex`, `compareConcepts`, `compareLinks`, `comparePhilosophers`, `conceptById`, `linkIsInternal`, `linksByConcept`, `nodesByPhilosopher`, `otherEndColor`, `philosopherByName`, `rebuildIndexes`, `rubricById`, `storedRecord`, `traditionById`, `withoutEmptyOptional`

### `modules/core/link-facts.js`

Строк 86.

**Вывозит:** `buildReflexiveMap`, `directionMark`, `isReflexiveLink`, `isSymmetricLink`, `isTypologicalLink`, `linkHasTwoHeads`, `linksBothWays`, `orientLink`, `otherPhilosopher`, `reflexiveLinkOf`, `sumWeight`

**Ввозит:**

- из `./ns.js`: `DATA`, `S`
- из `./graph-index.js`: _ради побочного действия_

**Содержит:** `buildReflexiveMap`, `directionMark`, `isReflexiveLink`, `isSymmetricLink`, `isTypologicalLink`, `linkHasTwoHeads`, `linksBothWays`, `orientLink`, `otherPhilosopher`, `reflexiveLinkOf`, `sumWeight`

### `modules/core/long-task.js`

Строк 121.

**Вывозит:** `CHAIN_SEARCH`, `LoadingIndicator`, `showTemporaryMessage`

**Ввозит:** _ничего_

**Содержит:** `CHAIN_SEARCH`, `LoadingIndicator`, `showTemporaryMessage`

### `modules/core/ns.js`

Строк 33.

**Вывозит:** `DATA`, `MET`, `S`, `VIEWS`

**Ввозит:** _ничего_

**Содержит:** `DATA`, `FILES`, `MET`, `S`, `VIEWS`, `loaded`

### `modules/core/perms.js`

Строк 28.

**Вывозит:** `PERM`, `can`, `setPermissions`

**Ввозит:** _ничего_

**Содержит:** `PERM`, `can`, `granted`, `setPermissions`

### `modules/core/ready.js`

Строк 15.

**Вывозит:** `onLoad`, `onReady`

**Ввозит:** _ничего_

**Содержит:** `onLoad`, `onReady`

### `modules/core/relation-types.js`

Строк 59.

**Вывозит:** `CONN_WEIGHT_WORDS`, `LAYER_NAMES`, `WEIGHT_OPTIONS`, `WEIGHT_WORDS`, `relationHint`

**Ввозит:**

- из `./ns.js`: `DATA`
- из `./graph-index.js`: _ради побочного действия_

**Содержит:** `CONN_WEIGHT_WORDS`, `LAYER_NAMES`, `RELATION_HINTS`, `WEIGHT_OPTIONS`, `WEIGHT_WORDS`, `relationHint`

### `modules/core/search.js`

Строк 68.

**Вывозит:** `displaySearchResults`, `emptyList`, `pickConcepts`, `rowInner`

**Ввозит:**

- из `./ns.js`: `DATA`
- из `./visibility.js`: `isNodeVisible`
- из `./graph-index.js`: _ради побочного действия_

**Содержит:** `displaySearchResults`, `emptyList`, `pickConcepts`, `rowInner`

### `modules/core/session.js`

Строк 23.

**Вывозит:** `AUTH_ADMIN`, `authAccounts`, `authSession`, `setSessionUser`

**Ввозит:**

- из `./perms.js`: `PERM`, `setPermissions`

**Содержит:** `AUTH_ADMIN`, `authAccounts`, `authSession`, `setSessionUser`

### `modules/core/time.js`

Строк 13.

**Вывозит:** `CHRONOLOGY_MODES`, `MATURITY_AGE`

**Ввозит:** _ничего_

**Содержит:** `CHRONOLOGY_MODES`, `MATURITY_AGE`

### `modules/core/visibility.js`

Строк 13.

**Вывозит:** `isLinkVisible`, `isNodeVisible`

**Ввозит:**

- из `./ns.js`: `S`

**Содержит:** `S.visibleLinkSet`, `S.visibleNodeIds`, `isLinkVisible`, `isNodeVisible`

### `modules/data/backend.js`

Строк 123.

**Вывозит:** `lastSubmitResult`, `lastSubmitted`, `reportSubmit`, `submitChange`

**Ввозит:**

- из `../core/api.js`: `api`, `serverMode`
- из `../core/events.js`: `emit`
- из `../core/perms.js`: `PERM`, `can`
- из `./remote.js`: `applyFreshGraph`
- из `./save.js`: `trackDirectEdit`

**Содержит:** `commitMessageFor`, `lastSubmitResult`, `lastSubmitted`, `noticeTimer`, `reportSubmit`, `sendCommit`, `submitChange`

### `modules/data/commit-draft.js`

Строк 37.

**Вывозит:** `describeChange`

**Ввозит:** _ничего_

**Содержит:** `describeChange`, `sameValue`

### `modules/data/load.js`

Строк 9.

**Вывозит:** `loadData`

**Ввозит:**

- из `../core/ns.js`: `DATA`

**Содержит:** `loadData`

### `modules/data/mutate.js`

Строк 89.

**Вывозит:** `afterDataChange`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `emit`
- из `../core/graph-index.js`: `rebuildIndexes`
- из `./save.js`: `markDirty`
- из `../state/render.js`: `linkLayer`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `afterDataChange`, `rebuildDerivedIndexes`, `rebuildPhilosopherTraditions`

### `modules/data/remote.js`

Строк 186.

**Вывозит:** `applyFreshGraph`, `connectLive`, `disconnectLive`, `knownGraphVersion`, `liveSocket`, `pullGraphSince`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/api.js`: `api`, `serverMode`
- из `../core/events.js`: `emit`
- из `../core/session.js`: `authSession`
- из `./mutate.js`: `afterDataChange`
- из `../state/render.js`: `applyServerLayout`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `S.liveClosedOnPurpose`, `applyFreshGraph`, `applyIncrement`, `connectLive`, `disconnectLive`, `knownGraphVersion`, `liveRetry`, `liveSocket`, `pullGraphSince`, `rebuildDerived`, `replaceEntity`

### `modules/data/save.js`

Строк 87.

**Вывозит:** `DATA_SETS`, `collectData`, `downloadData`, `hasUnsaved`, `installUnsavedGuard`, `markDirty`, `saveToFolder`, `trackDirectEdit`

**Ввозит:**

- из `../core/ns.js`: `DATA`
- из `../core/api.js`: `serverMode`

**Содержит:** `DATA_SETS`, `collectData`, `dataFolder`, `deliverFile`, `downloadData`, `hasUnsaved`, `hasUnsavedEdits`, `installUnsavedGuard`, `markDirty`, `saveToFolder`, `trackDirectEdit`, `unconfirmedDirect`

### `modules/dead.js`

Строк 86.

**Вывозит:** `TENSION_WEIGHTS`, `findConnectedComponents`, `graphSelectionContext`, `searchNodes`, `tensionScales`, `toggleSimilarityKind`

**Ввозит:**

- из `./core/ns.js`: `DATA`, `MET`, `S`
- из `./core/search.js`: `pickConcepts`
- из `./metrics/graph-cache.js`: `buildGlobalGraphCache`
- из `./render/similarity-overlay.js`: `showSimilarityOverlay`
- из `./core/graph-index.js`: _ради побочного действия_

**Содержит:** `TENSION_WEIGHTS`, `findConnectedComponents`, `graphSelectionContext`, `searchNodes`, `tensionScales`, `toggleSimilarityKind`

### `modules/filters/beyond-filter.js`

Строк 21.

**Вывозит:** `resetBeyondFilter`, `updateFilterNote`

**Ввозит:**

- из `./filters.js`: `applyFiltersImmediate`
- из `../state/filters.js`: `pinnedDespiteFilter`, `pinnedVisibleNodes`

**Содержит:** `resetBeyondFilter`, `updateFilterNote`

### `modules/filters/chains.js`

Строк 273.

**Вывозит:** `confirmLongChainSearch`, `findChainsThroughAllPhilosophers`, `findUniquePhilosopherChains`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/link-facts.js`: `isSymmetricLink`
- из `../core/long-task.js`: `CHAIN_SEARCH`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `CHAIN_WARN_THRESHOLD`, `buildAdjacencyGraph`, `confirmLongChainSearch`, `findChainsThroughAllPhilosophers`, `findUniquePhilosopherChains`, `processBFS`

### `modules/filters/filters.js`

Строк 443.

**Вывозит:** `applyFilters`, `applyFiltersImmediate`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `emit`
- из `../core/long-task.js`: `CHAIN_SEARCH`, `LoadingIndicator`, `showTemporaryMessage`
- из `../core/visibility.js`: `isLinkVisible`, `isNodeVisible`
- из `./chains.js`: `confirmLongChainSearch`, `findChainsThroughAllPhilosophers`, `findUniquePhilosopherChains`
- из `../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../metrics/scope-reset.js`: `invalidateEverythingForScope`
- из `../metrics/scope.js`: `updateMetricsScopeHint`
- из `../render/d3-layer.js`: `gfxLinkAll`, `gfxNode`
- из `../render/selection.js`: `highlightConnected`, `resetHighlight`
- из `../state/filters.js`: `pinnedDespiteFilter`, `pinnedVisibleNodes`
- из `../state/render.js`: `selectedNodes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `FilterModes`, `applyBasicFilter`, `applyChainVisibility`, `applyFilters`, `applyFiltersImmediate`, `cleanupInvisibleSelections`, `debounce`, `debouncedApplyFilters`, `handleChainsMode`, `handleUniqueChainsMode`, `refreshMetricsIfScoped`, `sharesTradition`

### `modules/graph/click-actions.js`

Строк 201.

**Вывозит:** `handleLinkClick`, `handleNodeClick`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/events.js`: `emit`
- из `../core/perms.js`: `PERM`, `can`
- из `./graph-selection.js`: `handleConceptSelection`
- из `../render/d3-layer.js`: `gfxNode`
- из `../render/selection.js`: `highlightCombined`, `isEdgeConnectedToSelectedNodes`, `isNodeConnectedToSelectedEdges`
- из `../state/edit.js`: `editMode`
- из `../state/render.js`: `selectedEdges`, `selectedNodes`

**Содержит:** `clickCount`, `clickTimer`, `handleLinkClick`, `handleLinkSelect`, `handleNodeClick`, `lastClickedNode`, `linkClickCount`, `linkClickTimer`

### `modules/graph/graph-data.js`

Строк 121.

**Вывозит:** `addLinkToGraph`, `addNodeToGraph`, `connectionsBetween`, `findConnection`, `forgetLink`, `forgetNode`, `getConceptConnections`, `traditionsOfPhilosopher`, `updateLinkOnGraph`, `updateNodeOnGraph`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `emit`
- из `../core/graph-index.js`: `conceptById`, `linksByConcept`, `traditionById`
- из `../render/canvas-core.js`: `renderState`
- из `../render/loop.js`: `requestDraw`
- из `../render/scene.js`: `updateGraphData`
- из `../state/filters.js`: `pinnedVisibleNodes`
- из `../state/render.js`: `linkLayer`, `selectedEdges`, `selectedNodes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `addLinkToGraph`, `addNodeToGraph`, `connectionsBetween`, `findConnection`, `forgetLink`, `forgetNode`, `getConceptConnections`, `traditionsOfPhilosopher`, `updateLinkOnGraph`, `updateNodeOnGraph`

### `modules/graph/graph-selection.js`

Строк 61.

**Вывозит:** `cancelGraphSelection`, `handleConceptSelection`, `selectConceptOnGraph`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/events.js`: `emit`
- из `../render/canvas-core.js`: `gfxCanvas`

**Содержит:** `cancelGraphSelection`, `handleConceptSelection`, `selectConceptOnGraph`

### `modules/metrics/by-link-type.js`

Строк 116.

**Вывозит:** `invalidateAbstractionIndexCache`, `invalidateDeductiveIndexCache`, `invalidateInstrumentalIndexCache`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `../core/link-facts.js`: `sumWeight`

**Содержит:** `MET.abstractionIndex`, `MET.deductiveDepth`, `MET.deductiveIndex`, `MET.instrumentalIndex`, `abstractionIndexCache`, `deductiveIndexCache`, `instrumentalIndexCache`, `invalidateAbstractionIndexCache`, `invalidateDeductiveIndexCache`, `invalidateInstrumentalIndexCache`

### `modules/metrics/concept-dynamics.js`

Строк 224.

**Вывозит:** `invalidateConceptualComplexityIndexCache`, `invalidateConceptualContinuityIndexCache`, `invalidateConceptualFertilityIndexCache`, `invalidateTransformationIndexCache`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `../core/link-facts.js`: `otherPhilosopher`, `reflexiveLinkOf`, `sumWeight`

**Содержит:** `MET.conceptualComplexityIndex`, `MET.conceptualContinuityIndex`, `MET.conceptualFertilityIndex`, `MET.transformationIndex`, `conceptualComplexityIndexCache`, `conceptualContinuityIndexCache`, `conceptualFertilityIndexCache`, `invalidateConceptualComplexityIndexCache`, `invalidateConceptualContinuityIndexCache`, `invalidateConceptualFertilityIndexCache`, `invalidateTransformationIndexCache`, `transformationIndexCache`

### `modules/metrics/descriptions.js`

Строк 478.

**Вывозит:** `getMetricDescription`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `./similarity-philosophers.js`: `PHIL_SIM_MIN_RUBRIC_UNION`
- из `./tradition-bridging.js`: `BRIDGING_MIN_EXTERNAL`, `BRIDGING_WEIGHT_REF`

**Содержит:** `getMetricDescription`, `metricDescriptions`

### `modules/metrics/format.js`

Строк 32.

**Вывозит:** `applyMetricMode`, `toggleMetricValueMode`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/events.js`: `emit`

**Содержит:** `applyMetricMode`, `conceptDegreeForNorm`, `normalizeMetricValue`, `toggleMetricValueMode`

### `modules/metrics/generativity.js`

Строк 110.

**Вывозит:** `generativity`, `invalidateGenerativityCache`, `linkInInfluenceScope`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`

**Содержит:** `GENERATIVITY_DAMPING`, `GENERATIVITY_ITERATIONS`, `MET.generativeIndex`, `_generativityCacheByScope`, `generativity`, `generativityScores`, `invalidateGenerativityCache`, `linkInInfluenceScope`, `sameTraditionPhil`

### `modules/metrics/graph-cache.js`

Строк 129.

**Вывозит:** `buildGlobalGraphCache`, `invalidateGraphCache`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/link-facts.js`: `isSymmetricLink`
- из `./scope-select.js`: `metricsLinks`, `metricsNodes`

**Содержит:** `buildGlobalGraphCache`, `graphCache`, `invalidateGraphCache`

### `modules/metrics/link-indexes.js`

Строк 122.

**Вывозит:** `initializePhilosophyMetrics`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/link-facts.js`: `buildReflexiveMap`, `isReflexiveLink`, `isSymmetricLink`
- из `../core/visibility.js`: `isNodeVisible`
- из `./scope-select.js`: `effectiveScopeFlags`, `transformForScope`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `buildIncomingLinks`, `buildOutgoingLinks`, `initializeMetricsData`, `initializePhilosophyMetrics`

### `modules/metrics/network.js`

Строк 950.

**Вывозит:** `betweennessCache`, `calculateBetweennessAsync`, `closenessCache`, `eigenvectorCache`, `invalidateBetweennessCache`, `invalidateClosenessCache`, `invalidateClusteringCache`, `invalidateEigenvectorCache`, `invalidateLocalCohesionCache`, `invalidatePageRankCache`, `invalidateRichClubCache`, `invalidateWeightedClusteringCache`, `localCohesionCache`, `medianNodeDegree`, `nodeDegreeOf`, `pageRankCache`, `richClubCache`, `weightedClusteringCache`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `MET`, `S`
- из `../core/graph-index.js`: `conceptById`
- из `./graph-cache.js`: `buildGlobalGraphCache`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `MET.calculateBetweenness`, `MET.calculateClosenessCentrality`, `MET.calculateClusteringCoefficient`, `MET.calculateEigenvectorCentrality`, `MET.calculateLocalCohesion`, `MET.calculatePageRank`, `MET.calculateRichClubCoefficient`, `MET.calculateWeightedClustering`, `MET.calculateWeightedDegree`, `S._medianDegreeCache`, `WEIGHTED_CLUSTERING_MIN_DEGREE`, `betweennessCache`, `betweennessCalculating`, `bfsFromSource`, `calculateBetweennessAsync`, `closenessCache`, `closenessCalculating`, `clusteringCache`, `dijkstraFromSource`, `eigenvectorCache`, `eigenvectorCalculating`, `invalidateBetweennessCache`, `invalidateClosenessCache`, `invalidateClusteringCache`, `invalidateEigenvectorCache`, `invalidateLocalCohesionCache`, `invalidatePageRankCache`, `invalidateRichClubCache`, `invalidateWeightedClusteringCache`, `localCohesionCache`, `medianNodeDegree`, `nodeDegreeOf`, `pageRankCache`, `pageRankCalculating`, `richClubCache`, `weightedClusteringCache`

### `modules/metrics/philosopher.js`

Строк 308.

**Вывозит:** `invalidatePhilosopherHistoricalReachIndexCache`, `invalidatePhilosopherInterdisciplinaryIndexCache`, `invalidatePhilosopherProfileCache`, `invalidatePhilosopherSystematicIndexCache`, `invalidateTemporalInfluencePatternCache`, `philosopherProfile`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `./philosophical.js`: `DISRUPTIVE_TYPES`, `SYSTEMATIC_TYPES`

**Содержит:** `CONSTRUCTIVE_TYPES`, `MET.philosopherHistoricalReachIndex`, `MET.philosopherInterdisciplinaryIndex`, `MET.philosopherSystematicIndex`, `MET.temporalInfluencePattern`, `POLEMICAL_TYPES`, `invalidatePhilosopherHistoricalReachIndexCache`, `invalidatePhilosopherInterdisciplinaryIndexCache`, `invalidatePhilosopherProfileCache`, `invalidatePhilosopherSystematicIndexCache`, `invalidateTemporalInfluencePatternCache`, `philosopherHistoricalReachIndexCache`, `philosopherInterdisciplinaryIndexCache`, `philosopherProfile`, `philosopherProfileCache`, `philosopherSystematicIndexCache`, `temporalInfluencePatternCache`

### `modules/metrics/philosophical.js`

Строк 1130.

**Вывозит:** `DISRUPTIVE_TYPES`, `FORMULA_VERSIONS`, `INFLUENCE_SCOPE_LABELS`, `SYSTEMATIC_TYPES`, `invalidateCriticalPowerIndexCache`, `invalidateDialogicalIndexCache`, `invalidateFoundationalIndexCache`, `invalidateInfluenceIndexCache`, `invalidateInternalCoherenceIndexCache`, `invalidateParadigmShiftIndexCache`, `invalidateProblemGenerationIndexCache`, `invalidateRevolutionaryIndexCache`, `invalidateSyntheticIndexCache`, `invalidateTensionIndexCache`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `MET`, `S`
- из `../core/link-facts.js`: `isSymmetricLink`, `linksBothWays`, `otherPhilosopher`, `reflexiveLinkOf`, `sumWeight`
- из `./generativity.js`: `generativity`, `linkInInfluenceScope`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `DISRUPTIVE_TYPES`, `FORMULA_VERSIONS`, `INFLUENCE_SCOPE_LABELS`, `MET.criticalPowerIndex`, `MET.dialogicalIndex`, `MET.foundationalIndex`, `MET.influenceIndex`, `MET.internalCoherenceIndex`, `MET.paradigmShiftIndex`, `MET.problemGenerationIndex`, `MET.revolutionaryIndex`, `MET.syntheticIndex`, `MET.tensionIndex`, `MUTUAL_DIALOGUE_BONUS`, `SYSTEMATIC_TYPES`, `criticalPowerIndexCache`, `dialogicalIndexCache`, `foundationalIndexCache`, `influenceIndexCache`, `internalCoherenceIndexCache`, `invalidateCriticalPowerIndexCache`, `invalidateDialogicalIndexCache`, `invalidateFoundationalIndexCache`, `invalidateInfluenceIndexCache`, `invalidateInternalCoherenceIndexCache`, `invalidateParadigmShiftIndexCache`, `invalidateProblemGenerationIndexCache`, `invalidateRevolutionaryIndexCache`, `invalidateSyntheticIndexCache`, `invalidateTensionIndexCache`, `paradigmShiftIndexCache`, `problemGenerationIndexCache`, `revolutionaryIndexCache`, `syntheticIndexCache`, `tensionIndexCache`

### `modules/metrics/rankings.js`

Строк 141.

**Вывозит:** `generatePhilosopherRankings`, `generateRankings`, `invalidateGeneratePhilosopherRankingsCache`, `invalidateGenerateRankingsCache`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `./format.js`: `applyMetricMode`
- из `./philosopher.js`: `philosopherProfile`

**Содержит:** `S.generateRankingsCache`, `generatePhilosopherRankings`, `generatePhilosopherRankingsCache`, `generateRankings`, `invalidateGeneratePhilosopherRankingsCache`, `invalidateGenerateRankingsCache`

### `modules/metrics/scope-reset.js`

Строк 64.

**Вывозит:** `invalidateEverythingForScope`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `./by-link-type.js`: `invalidateAbstractionIndexCache`, `invalidateDeductiveIndexCache`, `invalidateInstrumentalIndexCache`
- из `./concept-dynamics.js`: `invalidateConceptualComplexityIndexCache`, `invalidateConceptualContinuityIndexCache`, `invalidateConceptualFertilityIndexCache`, `invalidateTransformationIndexCache`
- из `./generativity.js`: `invalidateGenerativityCache`
- из `./graph-cache.js`: `invalidateGraphCache`
- из `./network.js`: `invalidateBetweennessCache`, `invalidateClosenessCache`, `invalidateClusteringCache`, `invalidateEigenvectorCache`, `invalidateLocalCohesionCache`, `invalidatePageRankCache`, `invalidateRichClubCache`, `invalidateWeightedClusteringCache`
- из `./philosopher.js`: `invalidatePhilosopherHistoricalReachIndexCache`, `invalidatePhilosopherInterdisciplinaryIndexCache`, `invalidatePhilosopherProfileCache`, `invalidatePhilosopherSystematicIndexCache`, `invalidateTemporalInfluencePatternCache`
- из `./philosophical.js`: `invalidateCriticalPowerIndexCache`, `invalidateDialogicalIndexCache`, `invalidateFoundationalIndexCache`, `invalidateInfluenceIndexCache`, `invalidateInternalCoherenceIndexCache`, `invalidateParadigmShiftIndexCache`, `invalidateProblemGenerationIndexCache`, `invalidateRevolutionaryIndexCache`, `invalidateSyntheticIndexCache`, `invalidateTensionIndexCache`
- из `./rankings.js`: `invalidateGeneratePhilosopherRankingsCache`, `invalidateGenerateRankingsCache`
- из `./similarity-concepts.js`: `invalidateSimilarityCache`
- из `./tension-cache.js`: `invalidateTensionScales`
- из `./tradition-bridging.js`: `invalidateTraditionBridgingCache`

**Содержит:** `invalidateAllMetricsCaches`, `invalidateEverythingForScope`, `invalidateMetricCoverageCache`

### `modules/metrics/scope-select.js`

Строк 99.

**Вывозит:** `METRIC_FLAGS`, `VIEW_METRIC`, `effectiveScopeFlags`, `metricsLinks`, `metricsNodes`, `transformForScope`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `METRIC_FLAGS`, `VIEW_METRIC`, `effectiveScopeFlags`, `metricsLinks`, `metricsNodes`, `transformForScope`

### `modules/metrics/scope.js`

Строк 149.

**Вывозит:** `applyMetricsScope`, `handleMetricsScopeChange`, `installMetricScopeWrappers`, `liveScopeKey`, `metricsScopeCounts`, `updateMetricsScopeHint`, `updateScopeToggles`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `MET`, `S`
- из `../core/events.js`: `emit`
- из `../core/visibility.js`: `isNodeVisible`
- из `./graph-cache.js`: `invalidateGraphCache`
- из `./link-indexes.js`: `initializePhilosophyMetrics`
- из `./scope-reset.js`: `invalidateEverythingForScope`
- из `./scope-select.js`: `METRIC_FLAGS`, `VIEW_METRIC`, `effectiveScopeFlags`, `transformForScope`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `S.cachesMatchLive`, `S.lastScopeKey`, `applyMetricsScope`, `handleMetricsScopeChange`, `installMetricScopeWrappers`, `liveScopeKey`, `metricScopeFactor`, `metricsScopeCounts`, `updateMetricsScopeHint`, `updateScopeToggles`

### `modules/metrics/similarity-concepts.js`

Строк 493.

**Вывозит:** `NETWORK_ROLE_WORDS`, `SIGNED_SIMILARITY`, `SIM_SHARED_HIGH`, `_pairCalculating`, `_simCache`, `allConceptPairs`, `allConceptPairsAsync`, `ensureNetworkProfile`, `fillPairsNetwork`, `invalidateSimilarityCache`, `nearestConcepts`, `networkProgressPercent`, `networkRoleOf`, `networkSimilarity`, `networkSimilarityData`, `profileIsMeaningful`, `profileSimilarity`, `similarityData`, `similarityNeedsDegree`, `similarityThresholds`, `structuralSimilarity`, `typeStyleSimilarity`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `./network.js`: `betweennessCache`, `calculateBetweennessAsync`, `closenessCache`, `eigenvectorCache`, `medianNodeDegree`, `nodeDegreeOf`, `pageRankCache`
- из `./similarity-philosophers.js`: `invalidatePhilosopherSimilarityCache`

**Содержит:** `NETWORK_PROGRESS_WEIGHTS`, `NETWORK_ROLE_OF`, `NETWORK_ROLE_WORDS`, `NETWORK_SIM_NAMES`, `PAIRS_CHUNK_ROWS`, `SIGNED_SIMILARITY`, `SIM_SHARED_HIGH`, `SIM_VERDICT_HIGH_Q`, `SIM_VERDICT_LOW_Q`, `_neighborCache`, `_netProgress`, `_netProgressListeners`, `_netSimCache`, `_netSimPending`, `_pairCache`, `_pairCalculating`, `_simCache`, `_simThresholdCache`, `_typeStyleCache`, `allConceptPairs`, `allConceptPairsAsync`, `centerRows`, `ensureNetworkProfile`, `fillPairsNetwork`, `invalidateSimilarityCache`, `metricValueMap`, `nearestConcepts`, `neighborSets`, `networkProgressPercent`, `networkRoleOf`, `networkSimilarity`, `networkSimilarityData`, `normedDot`, `profileIsMeaningful`, `profileSimilarity`, `similarityData`, `similarityNeedsDegree`, `similarityOf`, `similarityThresholds`, `structuralSimilarity`, `typeProfileOf`, `typeStyleData`, `typeStyleSimilarity`, `vectorNorm`, `zColumns`

### `modules/metrics/similarity-philosophers.js`

Строк 166.

**Вывозит:** `PHIL_SIM_LABELS`, `PHIL_SIM_MIN_RUBRIC_UNION`, `SIM_METRIC_LABELS`, `invalidatePhilosopherSimilarityCache`, `nearestPhilosophers`, `philosopherSimilarity`, `philosopherSimilarityData`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `./philosopher.js`: `philosopherProfile`

**Содержит:** `PHIL_SIM_LABELS`, `PHIL_SIM_MIN_CONCEPTS`, `PHIL_SIM_MIN_RUBRIC_UNION`, `SIM_METRIC_LABELS`, `_philSimCache`, `cosineOf`, `invalidatePhilosopherSimilarityCache`, `nearestPhilosophers`, `philosopherSimilarity`, `philosopherSimilarityData`, `rubricUnionSize`

### `modules/metrics/tension-cache.js`

Строк 13.

**Вывозит:** `invalidateTensionScales`

**Ввозит:**

- из `../core/ns.js`: `S`

**Содержит:** `S._tensionScales`, `S._tensionScalesComputing`, `invalidateTensionScales`

### `modules/metrics/tradition-bridging.js`

Строк 89.

**Вывозит:** `BRIDGING_MIN_EXTERNAL`, `BRIDGING_WEIGHT_REF`, `invalidateTraditionBridgingCache`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `../core/link-facts.js`: `isTypologicalLink`

**Содержит:** `BRIDGING_MIN_EXTERNAL`, `BRIDGING_WEIGHT_REF`, `MET.traditionBridgingIndex`, `invalidateTraditionBridgingCache`, `traditionBridgingCache`

### `modules/modal/assembly.js`

Строк 56.

**Вывозит:** `modalActions`, `modalContentFor`, `modalEntityExists`

**Ввозит:**

- из `../core/ns.js`: `VIEWS`
- из `./forms.js`: `commitReasonField`

**Содержит:** `modalActions`, `modalContentFor`, `modalEntityExists`

### `modules/modal/auth.js`

Строк 247.

**Вывозит:** `authLogout`, `closeAuthModal`, `openAuthModal`, `submitAuth`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/api.js`: `api`, `detectServerMode`, `serverMode`
- из `../core/events.js`: `emit`
- из `../core/session.js`: `AUTH_ADMIN`, `authAccounts`, `setSessionUser`
- из `../data/backend.js`: `reportSubmit`
- из `../data/remote.js`: `connectLive`, `disconnectLive`, `pullGraphSince`
- из `./context.js`: `ModalContext`
- из `./core.js`: `toggleModalMode`
- из `./edit-rights.js`: `refreshEditHints`, `refreshOpenModalToolbar`, `renderAuthControls`

**Содержит:** `S.authModalKind`, `authError`, `authLogout`, `authModalEl`, `authNoticeAdmin`, `authNoticeMember`, `closeAuthModal`, `logoutInFlight`, `openAuthModal`, `showAuthNotice`, `submitAuth`

### `modules/modal/commits.js`

Строк 444.

**Вывозит:** `applyRelayout`, `askLayoutRevert`, `cancelLayoutRevert`, `closeCommitsPanel`, `commitError`, `commitItems`, `commitTab`, `doLayoutRevert`, `layoutHistoryItems`, `layoutPlan`, `layoutRevertTo`, `loadCommits`, `loadLayoutHistory`, `openCommitsPanel`, `planRelayout`, `revertCommitFromPanel`, `reviewCommitFromPanel`, `showImpact`, `switchCommitTab`

**Ввозит:**

- из `../core/api.js`: `api`
- из `../core/events.js`: `emit`
- из `../core/long-task.js`: `showTemporaryMessage`
- из `../core/perms.js`: `PERM`, `can`
- из `../data/remote.js`: `pullGraphSince`
- из `./forms.js`: `PROVENANCE_STATES`
- из `../util/html.js`: `FOOTNOTE_LABELS`, `escapeAttr`

**Содержит:** `COMMIT_STATES`, `LAYOUT_KINDS`, `applyRelayout`, `askLayoutRevert`, `cancelLayoutRevert`, `closeCommitsPanel`, `commitError`, `commitItems`, `commitStateKind`, `commitStateWords`, `commitTab`, `describeImpact`, `doLayoutRevert`, `footnotesDiff`, `layoutError`, `layoutHistoryHtml`, `layoutHistoryItems`, `layoutPlan`, `layoutRevertTo`, `layoutTabHtml`, `loadCommits`, `loadLayoutHistory`, `openCommitsPanel`, `planRelayout`, `provenanceDiff`, `refreshEditCount`, `renderCommits`, `revertCommitFromPanel`, `reviewCommitFromPanel`, `showImpact`, `stateInWords`, `switchCommitTab`

### `modules/modal/concept-view.js`

Строк 442.

**Вывозит:** `computeSimilarNetworkColumn`, `forceSimilarColumn`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `VIEWS`
- из `../core/graph-index.js`: `conceptById`, `otherEndColor`, `rubricById`, `storedRecord`
- из `../core/link-facts.js`: `orientLink`
- из `../metrics/network.js`: `medianNodeDegree`, `nodeDegreeOf`
- из `../metrics/similarity-concepts.js`: `ensureNetworkProfile`, `nearestConcepts`, `networkProgressPercent`, `networkSimilarityData`, `profileIsMeaningful`
- из `./connection-view.js`: `linkArrow`
- из `./history.js`: `historyBlock`
- из `../util/color.js`: `getContrastColor`
- из `../util/html.js`: `footnoteOrder`, `footnotedText`, `footnotesBlock`, `liveProgressHtml`, `provenanceBlock`, `updateLiveProgress`, `withoutFootnotes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `VIEWS.generateConceptViewContent`, `_forcedSimilar`, `computeSimilarNetworkColumn`, `forceButtonHtml`, `forceSimilarColumn`, `refreshSimilarColumn`, `refreshSimilarNetworkColumn`, `similarColumnHtml`, `similarConceptsBlock`, `similarForced`, `similarItemHtml`, `similarNetworkColumnHtml`, `similarProfileColumnHtml`

### `modules/modal/conflict.js`

Строк 88.

**Вывозит:** `closeConflictModal`, `lastConflict`, `rebuildOverCurrent`, `showConflict`, `warnRemoteEdit`

**Ввозит:**

- из `../core/api.js`: `api`
- из `../data/backend.js`: `reportSubmit`
- из `../data/remote.js`: `applyFreshGraph`
- из `./context.js`: `ModalContext`
- из `./core.js`: `closeUniversalModal`
- из `./entry.js`: `openEditConceptModal`, `openEditPhilosopherModal`
- из `../util/html.js`: `escapeAttr`

**Содержит:** `closeConflictModal`, `lastConflict`, `rebuildOverCurrent`, `showConflict`, `warnRemoteEdit`

### `modules/modal/connection-edit.js`

Строк 289.

**Вывозит:** `createNewConceptForPhilosopher`, `createNewConnectionForConcept`, `onConnTypeChange`, `selectConnectionEditConcept`, `swapConnectionConcepts`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `VIEWS`
- из `../core/graph-index.js`: `conceptById`, `storedRecord`
- из `../core/link-facts.js`: `isReflexiveLink`
- из `../core/relation-types.js`: `LAYER_NAMES`, `WEIGHT_OPTIONS`, `relationHint`
- из `../core/search.js`: `emptyList`, `pickConcepts`, `rowInner`
- из `../graph/graph-data.js`: `connectionsBetween`
- из `./assembly.js`: `modalActions`
- из `./connection-view.js`: `initConnectionSearchFields`
- из `./context.js`: `ModalContext`
- из `./core.js`: `openUniversalModal`
- из `./forms.js`: `footnotesField`, `provenanceField`
- из `../util/html.js`: `escapeAttr`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `VIEWS.generateConnectionEditContent`, `connEditSelectedBlock`, `createNewConceptForPhilosopher`, `createNewConnectionForConcept`, `handleConnectionEditSearch`, `onConnTypeChange`, `selectConnectionEditConcept`, `setupConnectionEditSearchHandlers`, `swapConnectionConcepts`, `updateConnEditPairNote`

### `modules/modal/connection-view.js`

Строк 421.

**Вывозит:** `handleConnectionViewSearch`, `initConnectionSearchFields`, `linkArrow`, `selectConnectionViewConcept`, `toggleConnectionSearchSection`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `VIEWS`
- из `../core/graph-index.js`: `conceptById`, `storedRecord`, `traditionById`
- из `../core/link-facts.js`: `isReflexiveLink`
- из `../core/relation-types.js`: `CONN_WEIGHT_WORDS`, `WEIGHT_WORDS`, `relationHint`
- из `../core/search.js`: `emptyList`, `pickConcepts`, `rowInner`
- из `../graph/graph-data.js`: `connectionsBetween`, `traditionsOfPhilosopher`
- из `../graph/graph-selection.js`: `selectConceptOnGraph`
- из `./context.js`: `ModalContext`
- из `./history.js`: `historyBlock`
- из `../util/color.js`: `getContrastColor`
- из `../util/html.js`: `footnoteOrder`, `footnotedText`, `footnotesBlock`, `provenanceBlock`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `VIEWS.generateConnectionViewContent`, `conceptCircle`, `conceptPlate`, `connectionArrowSvg`, `connectionTraditionNote`, `generateConnectionVisualization`, `handleConnectionViewSearch`, `initConnectionSearchFields`, `linkArrow`, `selectConnectionViewConcept`, `toggleConnectionSearchSection`, `updateConnectionVisualization`

### `modules/modal/context.js`

Строк 11.

**Вывозит:** `ModalContext`

**Ввозит:** _ничего_

**Содержит:** `ModalContext`

### `modules/modal/core.js`

Строк 159.

**Вывозит:** `closeUniversalModal`, `modalStack`, `openUniversalModal`, `popModalState`, `toggleModalMode`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/events.js`: `emit`
- из `../core/perms.js`: `PERM`, `can`
- из `../graph/graph-selection.js`: `cancelGraphSelection`
- из `./assembly.js`: `modalContentFor`, `modalEntityExists`
- из `./connection-view.js`: `initConnectionSearchFields`
- из `./context.js`: `ModalContext`
- из `./dirty.js`: `hasUnsavedChanges`
- из `./search.js`: `clearModalSearch`
- из `../render/simulation.js`: `freezeSimulation`, `unfreezeSimulation`

**Содержит:** `MODAL_STACK_MAX`, `closeUniversalModal`, `modalStack`, `openUniversalModal`, `popModalState`, `pushModalState`, `toggleModalMode`

### `modules/modal/descriptions.js`

Строк 162.

**Вывозит:** `toggleAllConnectionDescriptions`, `toggleAllPhilosopherConceptDescriptions`, `toggleAllPhilosopherConnectionDescriptions`, `toggleConnectionDescription`, `togglePhilosopherConceptDescription`, `toggleSubsection`

**Ввозит:** _ничего_

**Содержит:** `allDescriptionsExpanded`, `allPhilosopherConceptDescriptionsExpanded`, `allPhilosopherConnectionDescriptionsExpanded`, `toggleAllConnectionDescriptions`, `toggleAllPhilosopherConceptDescriptions`, `toggleAllPhilosopherConnectionDescriptions`, `toggleAllRoot`, `toggleConnectionDescription`, `togglePhilosopherConceptDescription`, `toggleSubsection`

### `modules/modal/dirty.js`

Строк 116.

**Вывозит:** `hasUnsavedChanges`

**Ввозит:**

- из `../core/ns.js`: `DATA`
- из `../core/graph-index.js`: `philosopherByName`, `storedRecord`
- из `./assembly.js`: `modalEntityExists`
- из `./context.js`: `ModalContext`
- из `./forms.js`: `footnotesChanged`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `hasConceptChanges`, `hasConnectionChanges`, `hasFilledFields`, `hasPhilosopherChanges`, `hasUnsavedChanges`

### `modules/modal/edit-forms.js`

Строк 297.

**Вывозит:** `syncPhilColorFromPicker`, `updatePhilColorSample`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `VIEWS`
- из `../core/graph-index.js`: `conceptById`, `nodesByPhilosopher`, `philosopherByName`, `storedRecord`
- из `../core/link-facts.js`: `isReflexiveLink`
- из `../core/relation-types.js`: `relationHint`
- из `../graph/graph-data.js`: `getConceptConnections`
- из `./assembly.js`: `modalActions`
- из `./connection-view.js`: `linkArrow`
- из `./forms.js`: `footnotesField`, `provenanceField`
- из `../util/color.js`: `getContrastColor`
- из `../util/html.js`: `escapeAttr`
- из `../util/philosopher-label.js`: `philosopherYears`, `sortPhilosophersByBirth`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `VIEWS.generateConceptEditContent`, `VIEWS.generatePhilosopherEditContent`, `syncPhilColorFromPicker`, `updatePhilColorSample`

### `modules/modal/edit-rights.js`

Строк 61.

**Вывозит:** `philRowTip`, `refreshEditHints`, `refreshOpenModalToolbar`, `renderAuthControls`

**Ввозит:**

- из `../core/perms.js`: `PERM`, `can`
- из `../core/session.js`: `authSession`
- из `./context.js`: `ModalContext`
- из `./core.js`: `openUniversalModal`

**Содержит:** `philRowTip`, `refreshEditHints`, `refreshOpenModalToolbar`, `renderAuthControls`

### `modules/modal/entry.js`

Строк 124.

**Вывозит:** `closeDetailModal`, `closePhilosopherDetailModal`, `getIsolatedConceptsAfterDeletion`, `gotoNodeFromModal`, `isConceptIsolated`, `openConceptById`, `openEditConceptModal`, `openEditConnectionModal`, `openEditPhilosopherModal`, `showAllConcepts`, `showDetailModal`, `showPhilosopherDetailModal`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/graph-index.js`: `conceptById`, `nodesByPhilosopher`, `rubricById`
- из `../core/perms.js`: `PERM`, `can`
- из `../graph/graph-data.js`: `findConnection`, `getConceptConnections`
- из `./core.js`: `closeUniversalModal`, `openUniversalModal`
- из `../render/canvas-core.js`: `gfxSvg`
- из `../render/d3-layer.js`: `gfxNode`, `gfxZoom`
- из `../render/selection.js`: `highlightConnected`
- из `../state/render.js`: `selectedNodes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `closeDetailModal`, `closePhilosopherDetailModal`, `getIsolatedConceptsAfterDeletion`, `gotoNodeFromModal`, `isConceptIsolated`, `openConceptById`, `openEditConceptModal`, `openEditConnectionModal`, `openEditPhilosopherModal`, `showAllConcepts`, `showDetailModal`, `showPhilosopherDetailModal`

### `modules/modal/forms.js`

Строк 212.

**Вывозит:** `PROVENANCE_STATES`, `commitReasonField`, `footnotesChanged`, `footnotesField`, `footnotesValue`, `insertFootnote`, `installFootnoteLinks`, `provenanceField`, `provenanceValue`, `refreshFootnoteRows`, `refreshProvenanceField`, `removeFootnote`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/api.js`: `serverMode`
- из `../util/html.js`: `FOOTNOTE_LABELS`, `FOOTNOTE_STATE_ORDER`, `escapeAttr`, `footnoteOrder`

**Содержит:** `PROVENANCE_STATES`, `commitReasonField`, `footnoteHosts`, `footnoteRow`, `footnotesChanged`, `footnotesField`, `footnotesValue`, `insertFootnote`, `installFootnoteLinks`, `needsCitation`, `provenanceField`, `provenanceValue`, `refreshFootnoteRows`, `refreshProvenanceField`, `removeFootnote`

### `modules/modal/history.js`

Строк 114.

**Вывозит:** `historyBlock`, `renderEntityHistory`, `revertEntityToVersion`, `toggleEntityHistory`

**Ввозит:**

- из `../core/api.js`: `api`, `serverMode`
- из `../core/perms.js`: `PERM`, `can`
- из `../data/remote.js`: `pullGraphSince`
- из `./descriptions.js`: `toggleSubsection`
- из `../util/html.js`: `escapeAttr`

**Содержит:** `historyBlock`, `historyBusy`, `historyFor`, `historyItems`, `renderEntityHistory`, `revertEntityToVersion`, `toggleEntityHistory`

### `modules/modal/integrity.js`

Строк 265.

**Вывозит:** `conceptIntegrityWarnings`, `connectionIntegrityWarnings`, `nConcepts`, `nLinks`, `philosopherIntegrityWarnings`, `provenanceDriftWarning`, `relationIndexById`

**Ввозит:**

- из `../core/ns.js`: `DATA`
- из `../core/graph-index.js`: `conceptById`, `nodesByPhilosopher`, `philosopherByName`
- из `../core/link-facts.js`: `isReflexiveLink`
- из `./entry.js`: `isConceptIsolated`
- из `../util/philosopher-label.js`: `philosopherBirth`, `philosopherYears`
- из `../util/ru.js`: `pluralRu`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `GROUNDING_TYPES`, `activityOverlap`, `conceptIntegrityWarnings`, `connectionIntegrityWarnings`, `groundingCyclePath`, `labelOf`, `nConcepts`, `nLinks`, `philosopherIntegrityWarnings`, `provenanceDriftWarning`, `relationIndexById`

### `modules/modal/persist.js`

Строк 467.

**Вывозит:** `deleteConcept`, `deleteConnection`, `deletePhilosopher`, `saveConceptData`, `saveConnectionData`, `savePhilosopherData`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/graph-index.js`: `conceptById`, `nodesByPhilosopher`, `philosopherByName`, `storedRecord`, `withoutEmptyOptional`
- из `../core/link-facts.js`: `isReflexiveLink`
- из `../data/backend.js`: `submitChange`
- из `../data/commit-draft.js`: `describeChange`
- из `../data/mutate.js`: `afterDataChange`
- из `../graph/graph-data.js`: `addLinkToGraph`, `addNodeToGraph`, `findConnection`, `forgetLink`, `forgetNode`, `getConceptConnections`, `updateLinkOnGraph`, `updateNodeOnGraph`
- из `./assembly.js`: `modalEntityExists`
- из `./context.js`: `ModalContext`
- из `./core.js`: `closeUniversalModal`, `openUniversalModal`
- из `./entry.js`: `getIsolatedConceptsAfterDeletion`
- из `./forms.js`: `footnotesValue`, `provenanceValue`
- из `./integrity.js`: `conceptIntegrityWarnings`, `connectionIntegrityWarnings`, `nConcepts`, `nLinks`, `philosopherIntegrityWarnings`, `provenanceDriftWarning`, `relationIndexById`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `confirmWarnings`, `deleteConcept`, `deleteConnection`, `deletePhilosopher`, `generateId`, `provenanceFields`, `removeConceptEverywhere`, `removeLinkEverywhere`, `saveConceptData`, `saveConnectionData`, `savePhilosopherData`

### `modules/modal/philosopher-view.js`

Строк 668.

**Вывозит:** `makeLegendsEditable`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `VIEWS`
- из `../core/graph-index.js`: `comparePhilosophers`, `conceptById`, `nodesByPhilosopher`, `otherEndColor`, `philosopherByName`, `rubricById`, `traditionById`
- из `../core/link-facts.js`: `orientLink`
- из `../core/perms.js`: `PERM`, `can`
- из `../metrics/similarity-philosophers.js`: `nearestPhilosophers`
- из `./connection-view.js`: `linkArrow`
- из `./edit-rights.js`: `philRowTip`, `refreshEditHints`
- из `./entry.js`: `openEditPhilosopherModal`, `showPhilosopherDetailModal`
- из `./history.js`: `historyBlock`
- из `../render/selection.js`: `highlightPhilosopherOnGraph`
- из `../util/color.js`: `getContrastColor`
- из `../util/html.js`: `footnoteOrder`, `footnotedText`, `footnotesBlock`, `provenanceBlock`, `withoutFootnotes`
- из `../util/philosopher-label.js`: `formatBirthYear`, `philosopherBirth`, `philosopherYears`, `sortPhilosophersByBirth`
- из `../util/ru.js`: `conjugateVerb`, `declinePhilosopher`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `DATA_traditions_of`, `VIEWS.generatePhilosopherViewContent`, `makeLegendsEditable`, `philosopherTraditionsBlock`, `similarPhilosophersBlock`

### `modules/modal/profile-concept.js`

Строк 182.

**Вывозит:** `PROFILE_METRICS`, `closeConceptProfileModal`, `showConceptProfileModal`, `toggleProfileOrder`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `MET`, `S`
- из `../core/graph-index.js`: `conceptById`
- из `../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../metrics/scope.js`: `metricsScopeCounts`
- из `../render/simulation.js`: `freezeSimulation`, `unfreezeSimulation`
- из `../stats/coverage.js`: `METRIC_COVERAGE_WARN`, `metricCoverage`
- из `../util/color.js`: `getContrastColor`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `PROFILE_METRICS`, `closeConceptProfileModal`, `conceptDegreesDetailed`, `metricPartsText`, `metricPercentile`, `metricRank`, `showConceptProfileModal`, `toggleProfileOrder`

### `modules/modal/profile-philosopher.js`

Строк 121.

**Вывозит:** `closePhilosopherProfileModal`, `showPhilosopherProfileModal`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `MET`, `S`
- из `../core/graph-index.js`: `nodesByPhilosopher`, `philosopherByName`, `rubricById`
- из `../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `./profile-concept.js`: `PROFILE_METRICS`
- из `../render/simulation.js`: `freezeSimulation`, `unfreezeSimulation`
- из `../stats/coverage.js`: `METRIC_COVERAGE_WARN`, `metricCoverage`
- из `../util/color.js`: `getContrastColor`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `closePhilosopherProfileModal`, `showPhilosopherProfileModal`

### `modules/modal/search.js`

Строк 43.

**Вывозит:** `clearModalSearch`, `handleModalSearch`, `installModalSearchDismiss`

**Ввозит:**

- из `../core/search.js`: `displaySearchResults`, `pickConcepts`

**Содержит:** `clearModalSearch`, `handleModalSearch`, `installModalSearchDismiss`

### `modules/modal/security.js`

Строк 116.

**Вывозит:** `confirmMfaEnroll`, `openSecurityModal`, `refreshSecurityDone`, `startMfaEnroll`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/api.js`: `api`
- из `./edit-rights.js`: `refreshEditHints`, `renderAuthControls`
- из `../util/html.js`: `escapeAttr`

**Содержит:** `confirmMfaEnroll`, `openSecurityModal`, `refreshSecurityDone`, `securityError`, `securityModalEl`, `securitySecret`, `startMfaEnroll`

### `modules/modal/selection-list.js`

Строк 334.

**Вывозит:** `closeSelectionListModal`, `openSelectionLink`, `openSelectionListModal`, `provenanceState`, `renderSelectionList`, `selectionListMore`, `selectionListOpenBlocks`, `selectionListSets`, `selectionMirrorCount`, `setSelectionProvenance`, `toggleSelectionBlock`, `toggleSelectionBodies`, `toggleSelectionBody`

**Ввозит:**

- из `../core/ns.js`: `DATA`
- из `../core/graph-index.js`: `compareConcepts`, `compareLinks`, `comparePhilosophers`, `conceptById`, `linkIsInternal`, `otherEndColor`, `storedRecord`
- из `../core/link-facts.js`: `directionMark`, `linkHasTwoHeads`
- из `../core/visibility.js`: `isLinkVisible`, `isNodeVisible`
- из `./core.js`: `openUniversalModal`
- из `../render/simulation.js`: `freezeSimulation`, `unfreezeSimulation`
- из `../util/html.js`: `escapeAttr`, `withoutFootnotes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `PROVENANCE_LABELS`, `SELECTION_LIST_CHUNK`, `closeSelectionListModal`, `openSelectionLink`, `openSelectionListModal`, `provenanceKinds`, `provenanceState`, `renderSelectionList`, `selectionLabel`, `selectionListMore`, `selectionListOpenBlocks`, `selectionListOpenBodies`, `selectionListSets`, `selectionListShown`, `selectionMirrorCount`, `selectionPhilCount`, `selectionProvenance`, `selectionRowConcept`, `selectionRowPhilosopher`, `selectionRowRelation`, `setSelectionProvenance`, `toggleSelectionBlock`, `toggleSelectionBodies`, `toggleSelectionBody`

### `modules/modal/users.js`

Строк 97.

**Вывозит:** `banUserFromPanel`, `changeUserRoleFromPanel`, `closeUsersPanel`, `loadUsers`, `openUsersPanel`, `userItems`, `usersError`

**Ввозит:**

- из `../core/api.js`: `api`
- из `../core/perms.js`: `PERM`, `can`
- из `../util/html.js`: `escapeAttr`

**Содержит:** `banUserFromPanel`, `changeUserRoleFromPanel`, `closeUsersPanel`, `loadUsers`, `openUsersPanel`, `renderUsers`, `userItems`, `usersError`

### `modules/paths/analysis.js`

Строк 74.

**Вывозит:** `analyzePath`, `analyzePathTraditions`

**Ввозит:**

- из `../core/ns.js`: `DATA`
- из `../core/graph-index.js`: `conceptById`, `philosopherByName`, `traditionById`
- из `../core/link-facts.js`: `isSymmetricLink`
- из `../core/time.js`: `CHRONOLOGY_MODES`
- из `../graph/graph-data.js`: `traditionsOfPhilosopher`
- из `./chronology.js`: `isChronologicallyValid`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `analyzePath`, `analyzePathTraditions`

### `modules/paths/chronology.js`

Строк 175.

**Вывозит:** `installChronologyMode`, `installChronologyToggle`, `isChronologicallyValid`, `nodeAge`, `showChronologyModeIfOn`, `stepWithoutGap`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/graph-index.js`: `conceptById`, `philosopherByName`
- из `../core/time.js`: `CHRONOLOGY_MODES`, `MATURITY_AGE`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `DATA_nodes_find`, `installChronologyMode`, `installChronologyToggle`, `isChronologicallyValid`, `looseChronologyCheck`, `moderateChronologyCheck`, `nodeAge`, `showChronologyModeIfOn`, `stepWithoutGap`, `strictChronologyCheck`

### `modules/paths/path-descriptions.js`

Строк 180.

**Вывозит:** `closePathDescriptionsModal`, `showPathDescriptionsModal`, `togglePathNodesDescriptions`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/graph-index.js`: `philosopherByName`
- из `../core/relation-types.js`: `WEIGHT_WORDS`
- из `./analysis.js`: `analyzePathTraditions`
- из `./path-ui.js`: `resolvePathLinkList`
- из `../render/simulation.js`: `freezeSimulation`, `unfreezeSimulation`
- из `../util/color.js`: `getContrastColor`
- из `../util/html.js`: `withoutFootnotes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `closePathDescriptionsModal`, `nodesDescriptionsVisible`, `showPathDescriptionsModal`, `togglePathNodesDescriptions`

### `modules/paths/path-ui.js`

Строк 423.

**Вывозит:** `clearPathHighlight`, `findAndShowPath`, `handlePathArrowHover`, `initPathFinder`, `resolvePathLinkList`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `emit`
- из `../core/graph-index.js`: `conceptById`, `philosopherByName`
- из `../core/link-facts.js`: `isSymmetricLink`
- из `../core/time.js`: `CHRONOLOGY_MODES`
- из `./analysis.js`: `analyzePath`, `analyzePathTraditions`
- из `./shortest-path.js`: `findShortestPath`
- из `../render/d3-layer.js`: `gfxLinkAll`, `gfxNode`
- из `../render/selection.js`: `resetHighlight`
- из `../util/html.js`: `withoutFootnotes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `ARROW_HOVER_DELAY`, `arrowHoverTimer`, `clearPathHighlight`, `findAndShowPath`, `handlePathArrowHover`, `highlightPath`, `initPathFinder`, `resolvePathLinkList`

### `modules/paths/shortest-path.js`

Строк 203.

**Вывозит:** `findShortestPath`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/link-facts.js`: `isSymmetricLink`, `isTypologicalLink`
- из `../core/time.js`: `CHRONOLOGY_MODES`
- из `./chronology.js`: `isChronologicallyValid`, `nodeAge`, `stepWithoutGap`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `findShortestPath`, `findShortestPathUnweighted`, `findShortestPathWeighted`, `pathLinkAllowed`

### `modules/render/canvas-core.js`

Строк 38.

**Вывозит:** `PICK_LINK_WIDTH`, `ctx`, `dpr`, `gfxCanvas`, `gfxSvg`, `renderState`, `resizeCanvas`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `./loop.js`: `requestDraw`

**Содержит:** `PICK_LINK_WIDTH`, `ctx`, `dpr`, `gfxCanvas`, `gfxSvg`, `renderState`, `resizeCanvas`

### `modules/render/d3-layer.js`

Строк 106.

**Вывозит:** `dragMoveStarted`, `dragended`, `gfxLink`, `gfxLinkAll`, `gfxNode`, `gfxZoom`, `linkHandlers`, `nodeHandlers`, `updateArrows`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `./canvas-core.js`: `renderState`
- из `./loop.js`: `requestDraw`
- из `./scene.js`: `startRadiusAnimation`
- из `../state/render.js`: `resetLayoutClock`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `dragMoveStarted`, `dragended`, `gfxLink`, `gfxLinkAll`, `gfxNode`, `gfxZoom`, `linkHandlers`, `makeClassed`, `nodeHandlers`, `subSelection`, `updateArrows`

### `modules/render/draw-link.js`

Строк 73.

**Вывозит:** `CONTRADICTION_DASH`, `fillLinkHeads`, `linkDrawAlpha`, `linkDrawWidth`, `linkVisualState`, `strokeLinkShape`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `./canvas-core.js`: `renderState`
- из `./geometry.js`: `linkHoverStrokeWidth`, `linkStrokeWidth`
- из `./render-state.js`: `hasLinkClass`
- из `./similarity-overlay.js`: `linkAmongHighlighted`
- из `../state/render.js`: `selectedEdges`

**Содержит:** `CONTRADICTION_DASH`, `fillLinkHeads`, `linkDrawAlpha`, `linkDrawWidth`, `linkVisualState`, `strokeLinkShape`

### `modules/render/geometry.js`

Строк 105.

**Вывозит:** `clippedArc`, `linkHoverStrokeWidth`, `linkShape`, `linkStrokeWidth`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/link-facts.js`: `isReflexiveLink`, `linkHasTwoHeads`
- из `./canvas-core.js`: `renderState`
- из `./render-state.js`: `nodeOuterRadius`, `nodeRadius`

**Содержит:** `arcAngleOfChord`, `arcHead`, `arcParams`, `arrowSize`, `clippedArc`, `linkHoverStrokeWidth`, `linkShape`, `linkStrokeWidth`, `loopShape`

### `modules/render/grouping.js`

Строк 115.

**Вывозит:** `buildGroupPositions`, `installResize`, `toggleGrouping`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `./canvas-core.js`: `resizeCanvas`
- из `./selection.js`: `resetHighlight`
- из `../state/render.js`: `pullStrengthOf`, `resetLayoutClock`
- из `../core/graph-index.js`: _ради побочного действия_
- из `../state/render.js`: _ради побочного действия_

**Содержит:** `S.spacingX`, `S.spacingY`, `buildGroupPositions`, `cols`, `groupPositions`, `installResize`, `philosopherNames`, `rows`, `toggleGrouping`

### `modules/render/interactions.js`

Строк 318.

**Вывозит:** `initGraphEventHandlers`, `installLinkHover`, `installNodeDrag`, `installNodeHover`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `emit`
- из `../core/graph-index.js`: `conceptById`
- из `../core/link-facts.js`: `isReflexiveLink`, `isSymmetricLink`
- из `../core/perms.js`: `PERM`, `can`
- из `../graph/click-actions.js`: `handleLinkClick`, `handleNodeClick`
- из `../graph/graph-selection.js`: `cancelGraphSelection`, `handleConceptSelection`
- из `./canvas-core.js`: `gfxCanvas`, `gfxSvg`, `renderState`
- из `./d3-layer.js`: `dragMoveStarted`, `dragended`, `gfxLink`, `gfxNode`, `gfxZoom`, `linkHandlers`, `nodeHandlers`
- из `./loop.js`: `requestDraw`
- из `./picking.js`: `pickLink`, `pickNode`, `toGraph`
- из `./selection.js`: `resetHighlight`
- из `./tooltip-el.js`: `tooltip`
- из `../state/edit.js`: `editMode`
- из `../state/filters.js`: `chosenPhilosophers`
- из `../state/render.js`: `selectedEdges`
- из `../util/html.js`: `withoutFootnotes`
- из `../util/philosopher-label.js`: `labelWithAuthor`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `dispatchClick`, `dispatchMove`, `initGraphEventHandlers`, `installLinkHover`, `installNodeDrag`, `installNodeHover`, `lastHoverLink`, `lastHoverNode`

### `modules/render/loop.js`

Строк 20.

**Вывозит:** `requestDraw`, `setPainter`

**Ввозит:** _ничего_

**Содержит:** `drawScheduled`, `painter`, `requestDraw`, `setPainter`

### `modules/render/metric-visualization.js`

Строк 371.

**Вывозит:** `resetNodeSizes`, `saveOriginalRadii`, `toggleMetricVisualization`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `MET`, `S`
- из `../core/events.js`: `emit`
- из `../metrics/network.js`: `betweennessCache`, `closenessCache`, `eigenvectorCache`, `localCohesionCache`, `pageRankCache`, `richClubCache`, `weightedClusteringCache`
- из `./d3-layer.js`: `gfxNode`, `updateArrows`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `currentVisualizedMetric`, `isVisualizingBySize`, `originalRadii`, `originalTextDy`, `resetNodeSizes`, `saveOriginalRadii`, `toggleMetricVisualization`, `updateVisualizationButtonText`, `updateVisualizationControlSection`, `visualizeMetricBySize`

### `modules/render/picking.js`

Строк 95.

**Вывозит:** `pickLink`, `pickNode`, `toGraph`

**Ввозит:**

- из `../core/ns.js`: `DATA`
- из `../core/visibility.js`: `isLinkVisible`, `isNodeVisible`
- из `./canvas-core.js`: `PICK_LINK_WIDTH`, `gfxCanvas`, `renderState`
- из `./draw-link.js`: `linkDrawWidth`, `linkVisualState`
- из `./geometry.js`: `linkShape`, `linkStrokeWidth`
- из `./render-state.js`: `NODE_PASSES`, `nodeDrawPass`, `nodeRadius`
- из `./scene.js`: `DRAW_ORDER`, `linkDrawnLive`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `distToSegment`, `hitLinkShape`, `pickLink`, `pickNode`, `pointInTriangle`, `toGraph`

### `modules/render/render-state.js`

Строк 47.

**Вывозит:** `LABEL_ALL_ABOVE`, `LABEL_HIDE_BELOW`, `NODE_PASSES`, `hasLinkClass`, `hasNodeClass`, `nodeDrawPass`, `nodeEdgeWidth`, `nodeLabelDy`, `nodeOuterRadius`, `nodeRadius`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `./canvas-core.js`: `renderState`
- из `../state/render.js`: `selectedNodes`

**Содержит:** `LABEL_ALL_ABOVE`, `LABEL_HIDE_BELOW`, `NODE_PASSES`, `hasLinkClass`, `hasNodeClass`, `nodeDrawPass`, `nodeEdgeWidth`, `nodeLabelDy`, `nodeOuterRadius`, `nodeRadius`

### `modules/render/scene.js`

Строк 353.

**Вывозит:** `DRAW_ORDER`, `draw`, `ensureAnimLoop`, `linkDrawnLive`, `needsContinuousAnimation`, `renderScene`, `startRadiusAnimation`, `updateGraphData`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/graph-index.js`: `conceptById`
- из `../core/link-facts.js`: `isReflexiveLink`
- из `../core/visibility.js`: `isLinkVisible`, `isNodeVisible`
- из `./canvas-core.js`: `ctx`, `dpr`, `gfxCanvas`, `renderState`
- из `./draw-link.js`: `CONTRADICTION_DASH`, `fillLinkHeads`, `linkDrawAlpha`, `linkDrawWidth`, `linkVisualState`, `strokeLinkShape`
- из `./geometry.js`: `clippedArc`, `linkShape`
- из `./loop.js`: `requestDraw`
- из `./render-state.js`: `LABEL_ALL_ABOVE`, `LABEL_HIDE_BELOW`, `NODE_PASSES`, `hasLinkClass`, `hasNodeClass`, `nodeDrawPass`, `nodeEdgeWidth`, `nodeLabelDy`, `nodeRadius`
- из `./similarity-overlay.js`: `similarityColor`
- из `../state/render.js`: `linkLayer`, `resetLayoutClock`, `selectedEdges`, `selectedNodes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `DRAW_ORDER`, `LABEL_SHADOW_PASSES`, `animLoopRunning`, `draw`, `drawLinkSet`, `ensureAnimLoop`, `graphIsCovered`, `lastLayerKey`, `linkDrawnLive`, `linkOutOfLayer`, `linksLayerKey`, `needsContinuousAnimation`, `paintLinkLayer`, `renderScene`, `sameLayerKey`, `startRadiusAnimation`, `stepRadiusAnimation`, `updateGraphData`

### `modules/render/selection.js`

Строк 261.

**Вывозит:** `highlightCombined`, `highlightConnected`, `highlightNodeById`, `highlightPhilosopherOnGraph`, `isEdgeConnectedToSelectedNodes`, `isNodeConnectedToSelectedEdges`, `resetHighlight`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `emit`
- из `../core/graph-index.js`: `conceptById`
- из `../core/long-task.js`: `showTemporaryMessage`
- из `./canvas-core.js`: `gfxSvg`
- из `./d3-layer.js`: `gfxLinkAll`, `gfxNode`, `gfxZoom`
- из `./loop.js`: `requestDraw`
- из `../state/filters.js`: `chosenPhilosophers`
- из `../state/render.js`: `selectedEdges`, `selectedNodes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `highlightCombined`, `highlightConnected`, `highlightNodeById`, `highlightPhilosopherOnGraph`, `isEdgeConnectedToNode`, `isEdgeConnectedToSelectedNodes`, `isNodeConnectedToSelectedEdges`, `resetHighlight`

### `modules/render/similarity-overlay.js`

Строк 256.

**Вывозит:** `clearSimilarityOverlay`, `linkAmongHighlighted`, `setSimilarityLinks`, `showSimilarityOverlay`, `similarityColor`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `emit`
- из `../core/graph-index.js`: `conceptById`
- из `../core/long-task.js`: `showTemporaryMessage`
- из `../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../metrics/similarity-concepts.js`: `SIGNED_SIMILARITY`, `_simCache`, `ensureNetworkProfile`, `networkProgressPercent`, `networkSimilarity`, `networkSimilarityData`, `profileIsMeaningful`, `profileSimilarity`, `similarityNeedsDegree`, `structuralSimilarity`, `typeStyleSimilarity`
- из `./loop.js`: `requestDraw`
- из `../util/html.js`: `liveProgressHtml`, `updateLiveProgress`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `SIMILARITY_ARCS`, `SIMILARITY_KEEP_QUANTILE`, `clearSimilarityOverlay`, `linkAmongHighlighted`, `nodeLitBySimilarity`, `setSimilarityLinks`, `showSimilarityOverlay`, `similarityColor`, `similarityLinkCount`, `updateSimilarityLegend`

### `modules/render/simulation.js`

Строк 128.

**Вывозит:** `centerGraph`, `freezeSimulation`, `installSimulationLog`, `installSimulationStatsEnd`, `installSimulationTick`, `resetSimulation`, `toggleSimulationFreeze`, `unfreezeSimulation`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/long-task.js`: `showTemporaryMessage`
- из `./canvas-core.js`: `gfxSvg`
- из `./d3-layer.js`: `gfxZoom`
- из `./loop.js`: `requestDraw`
- из `./scene.js`: `ensureAnimLoop`, `needsContinuousAnimation`
- из `./selection.js`: `resetHighlight`
- из `../state/render.js`: `resetLayoutClock`
- из `../core/graph-index.js`: _ради побочного действия_
- из `../state/render.js`: _ради побочного действия_

**Содержит:** `S.maxTicks`, `centerGraph`, `freezeSimulation`, `installSimulationLog`, `installSimulationStatsEnd`, `installSimulationTick`, `maxTicksFor`, `resetSimulation`, `simLockedByHand`, `toggleSimulationFreeze`, `unfreezeSimulation`, `updateFreezeButton`

### `modules/render/tooltip-el.js`

Строк 7.

**Вывозит:** `tooltip`

**Ввозит:** _ничего_

**Содержит:** `tooltip`

### `modules/state/edit.js`

Строк 15.

**Вывозит:** `editMode`

**Ввозит:**

- из `../core/ns.js`: `S`

**Содержит:** `S.lastFootnoteHost`, `editMode`

### `modules/state/filters.js`

Строк 20.

**Вывозит:** `chosenPhilosophers`, `pinnedDespiteFilter`, `pinnedVisibleNodes`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `S.filterMode`, `S.selectedPhilosophers`, `S.selectedRelations`, `S.selectedRubrics`, `chosenPhilosophers`, `pinnedDespiteFilter`, `pinnedVisibleNodes`

### `modules/state/metrics-scope.js`

Строк 13.

**Вывозит:** _ничего_

**Ввозит:**

- из `../core/ns.js`: `S`

**Содержит:** `S.influenceScope`, `S.metricsLinkSource`, `S.metricsNodeSource`, `S.metricsScope`, `S.metricsScopeActive`

### `modules/state/paths.js`

Строк 18.

**Вывозит:** _ничего_

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/time.js`: `CHRONOLOGY_MODES`

**Содержит:** `S.currentChronologyMode`, `S.currentPathData`, `S.respectDirection`, `S.selectedSourceNode`, `S.selectedTargetNode`, `S.skipTypologicalInPaths`, `S.useWeightedPaths`

### `modules/state/render.js`

Строк 137.

**Вывозит:** `applyServerLayout`, `applyStoredLayout`, `graphFingerprint`, `installLayoutPull`, `layoutFromStore`, `linkLayer`, `pullStrengthOf`, `resetLayoutClock`, `selectedEdges`, `selectedNodes`, `storedLayoutComplaint`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `emit`
- из `../core/graph-index.js`: `linksByConcept`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `LAYOUT_PULL`, `S.arrowMode`, `S.isGrouped`, `S.layoutSettled`, `S.similarityOverlay`, `S.simulation`, `S.tickCount`, `S.uniformLinkWidthActive`, `S.viewHeight`, `S.viewWidth`, `applyServerLayout`, `applyStoredLayout`, `graphFingerprint`, `installLayoutPull`, `layoutFromStore`, `linkLayer`, `pullStrengthOf`, `resetLayoutClock`, `selectedEdges`, `selectedNodes`, `storedLayoutComplaint`

### `modules/state/stats.js`

Строк 33.

**Вывозит:** _ничего_

**Ввозит:**

- из `../core/ns.js`: `S`

**Содержит:** `S._cmpA`, `S._cmpB`, `S._pairsCrossAuthor`, `S._pairsCrossTradition`, `S._pairsKind`, `S._pairsMinDegree`, `S._pairsMinShared`, `S._pcmpA`, `S._pcmpB`, `S._philPairsKind`, `S.currentStatsView`, `S.generateRankingsMode`, `S.isStatsModalOpen`, `S.metricValueMode`, `S.profileOrderMode`

### `modules/stats/coverage.js`

Строк 66.

**Вывозит:** `METRIC_COVERAGE_WARN`, `generateMetricCoverageBlock`, `metricCoverage`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `../metrics/by-link-type.js`: _ради побочного действия_
- из `../metrics/concept-dynamics.js`: _ради побочного действия_
- из `../metrics/generativity.js`: _ради побочного действия_
- из `../metrics/philosophical.js`: _ради побочного действия_
- из `../metrics/tradition-bridging.js`: _ради побочного действия_

**Содержит:** `METRIC_COVERAGE_WARN`, `S.METRIC_COVERAGE_FN`, `S._metricCoverageCache`, `generateMetricCoverageBlock`, `metricCoverage`

### `modules/stats/modal.js`

Строк 269.

**Вывозит:** `closeStatsModal`, `handleStatsParameterChange`, `installStatsEscape`, `installStatsModalDismiss`, `loadStatsContent`, `openStatsModal`, `refreshObservationsNav`, `switchStatsView`, `updateActiveNavItem`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/api.js`: `serverMode`
- из `../core/events.js`: `emit`
- из `../core/session.js`: `authSession`
- из `../metrics/graph-cache.js`: `invalidateGraphCache`
- из `../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../metrics/scope-reset.js`: `invalidateEverythingForScope`
- из `../metrics/scope.js`: `applyMetricsScope`, `installMetricScopeWrappers`, `liveScopeKey`, `updateMetricsScopeHint`, `updateScopeToggles`
- из `../render/metric-visualization.js`: `resetNodeSizes`
- из `../render/scene.js`: `ensureAnimLoop`, `needsContinuousAnimation`
- из `../render/simulation.js`: `freezeSimulation`, `unfreezeSimulation`
- из `./observations.js`: `generateObservationsContent`, `observationBar`
- из `./results.js`: `applyMetricLayout`
- из `./views/advanced.js`: `generateAbstractionContent`, `generateBridgingContent`, `generateComplexityContent`, `generateContinuityContent`, `generateDeductiveContent`, `generateFertilityContent`, `generateGenerativeContent`, `generateInstrumentalContent`, `generateTemporalInfluenceContent`, `generateTransformationContent`
- из `./views/comparison.js`: `generateClosestPairsContent`, `generateComparisonContent`, `generatePhilosopherComparisonContent`, `generatePhilosopherPairsContent`, `renderClosestPairs`, `renderComparison`, `renderPhilosopherComparison`, `renderPhilosopherPairs`
- из `./views/network.js`: `generateBetweennessContent`, `generateClosenessContent`, `generateDegreeContent`, `generateEigenvectorContent`, `generateLocalCohesionContent`, `generateOverviewContent`, `generatePageRankContent`, `generateRichClubContent`, `generateWeightedClusteringContent`
- из `./views/philosopher.js`: `generatePhilosopherInterdisciplinaryContent`, `generatePhilosopherProfileContent`, `generatePhilosopherReachContent`, `generatePhilosopherSystematicContent`
- из `./views/philosophical.js`: `generateCoherenceContent`, `generateCriticalPowerContent`, `generateDialogicalContent`, `generateFoundationalContent`, `generateInfluenceContent`, `generateParadigmShiftContent`, `generateProblemGenerationContent`, `generateRevolutionaryContent`, `generateSyntheticContent`, `generateTensionContent`
- из `./views/rankings.js`: `generateConceptRankingsContent`, `generatePhilosopherRankingsContent`

**Содержит:** `closeStatsModal`, `handleStatsParameterChange`, `installStatsEscape`, `installStatsModalDismiss`, `loadStatsContent`, `observationsAllowed`, `openStatsModal`, `refreshObservationsNav`, `switchStatsView`, `updateActiveNavItem`

### `modules/stats/observations.js`

Строк 223.

**Вывозит:** `deleteObservation`, `generateObservationsContent`, `observationBar`, `pickObservation`, `saveObservation`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/api.js`: `api`, `serverMode`
- из `../core/perms.js`: `PERM`, `can`
- из `../metrics/philosophical.js`: `FORMULA_VERSIONS`
- из `../metrics/scope-select.js`: `VIEW_METRIC`, `effectiveScopeFlags`, `metricsNodes`
- из `../util/html.js`: `escapeAttr`

**Содержит:** `compareObservationsInPanel`, `deleteObservation`, `generateObservationsContent`, `loadObservations`, `observationBar`, `observationItems`, `observationPicked`, `observationValues`, `pickObservation`, `renderObservations`, `saveObservation`

### `modules/stats/results.js`

Строк 416.

**Вывозит:** `applyMetricLayout`, `generateCalculateButton`, `generateMetricDescriptionBlock`, `generateMetricResults`, `rankKeep`, `restoreMetricLayoutMode`, `toggleMetricDetails`, `toggleMetricLayout`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../metrics/descriptions.js`: `getMetricDescription`
- из `../metrics/format.js`: `applyMetricMode`
- из `./coverage.js`: `generateMetricCoverageBlock`
- из `../util/html.js`: `withoutFootnotes`

**Содержит:** `METRIC_FIELD_LABELS`, `S.metricLayoutMode`, `applyMetricLayout`, `generateCalculateButton`, `generateMetricDescriptionBlock`, `generateMetricResults`, `genericDetailsHTML`, `lastZeroCount`, `rankKeep`, `restoreMetricLayoutMode`, `toggleMetricDetails`, `toggleMetricLayout`

### `modules/stats/run.js`

Строк 128.

**Вывозит:** `calculateMetricFromModal`

**Ввозит:**

- из `../core/ns.js`: `MET`, `S`
- из `../metrics/network.js`: `calculateBetweennessAsync`
- из `./modal.js`: `openStatsModal`, `switchStatsView`, `updateActiveNavItem`

**Содержит:** `calculateMetricFromModal`, `hideProgress`, `runSingleMetric`, `showProgress`

### `modules/stats/views/advanced.js`

Строк 275.

**Вывозит:** `generateAbstractionContent`, `generateBridgingContent`, `generateComplexityContent`, `generateContinuityContent`, `generateDeductiveContent`, `generateFertilityContent`, `generateGenerativeContent`, `generateInstrumentalContent`, `generateTemporalInfluenceContent`, `generateTransformationContent`

**Ввозит:**

- из `../../core/ns.js`: `DATA`, `MET`
- из `../../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../results.js`: `generateMetricDescriptionBlock`, `generateMetricResults`, `rankKeep`
- из `../../core/graph-index.js`: _ради побочного действия_

**Содержит:** `generateAbstractionContent`, `generateBridgingContent`, `generateComplexityContent`, `generateContinuityContent`, `generateDeductiveContent`, `generateFertilityContent`, `generateGenerativeContent`, `generateInstrumentalContent`, `generateTemporalInfluenceContent`, `generateTransformationContent`

### `modules/stats/views/comparison.js`

Строк 508.

**Вывозит:** `computeComparisonNetwork`, `generateClosestPairsContent`, `generateComparisonContent`, `generatePhilosopherComparisonContent`, `generatePhilosopherPairsContent`, `openPairInComparison`, `openPhilosopherPair`, `renderClosestPairs`, `renderComparison`, `renderPhilosopherComparison`, `renderPhilosopherPairs`, `similarityVerdict`

**Ввозит:**

- из `../../core/ns.js`: `DATA`, `S`
- из `../../core/events.js`: `emit`
- из `../../core/graph-index.js`: `conceptById`
- из `../../core/long-task.js`: `LoadingIndicator`
- из `../../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../../metrics/philosopher.js`: `philosopherProfile`
- из `../../metrics/similarity-concepts.js`: `NETWORK_ROLE_WORDS`, `SIM_SHARED_HIGH`, `_pairCalculating`, `allConceptPairs`, `allConceptPairsAsync`, `ensureNetworkProfile`, `fillPairsNetwork`, `networkProgressPercent`, `networkRoleOf`, `networkSimilarity`, `profileIsMeaningful`, `profileSimilarity`, `similarityData`, `similarityThresholds`, `structuralSimilarity`, `typeStyleSimilarity`
- из `../../metrics/similarity-philosophers.js`: `PHIL_SIM_LABELS`, `SIM_METRIC_LABELS`, `philosopherSimilarity`, `philosopherSimilarityData`
- из `../results.js`: `generateMetricDescriptionBlock`
- из `../../util/html.js`: `liveProgressHtml`, `updateLiveProgress`
- из `../../core/graph-index.js`: _ради побочного действия_

**Содержит:** `computeComparisonNetwork`, `generateClosestPairsContent`, `generateComparisonContent`, `generatePhilosopherComparisonContent`, `generatePhilosopherPairsContent`, `openPairInComparison`, `openPhilosopherPair`, `renderClosestPairs`, `renderComparison`, `renderPhilosopherComparison`, `renderPhilosopherPairs`, `similarityVerdict`

### `modules/stats/views/network.js`

Строк 223.

**Вывозит:** `generateBetweennessContent`, `generateClosenessContent`, `generateDegreeContent`, `generateEigenvectorContent`, `generateLocalCohesionContent`, `generateOverviewContent`, `generatePageRankContent`, `generateRichClubContent`, `generateWeightedClusteringContent`

**Ввозит:**

- из `../../core/ns.js`: `DATA`, `MET`, `S`
- из `../../metrics/network.js`: `betweennessCache`, `closenessCache`, `eigenvectorCache`, `localCohesionCache`, `pageRankCache`, `richClubCache`, `weightedClusteringCache`
- из `../results.js`: `generateCalculateButton`, `generateMetricDescriptionBlock`, `generateMetricResults`
- из `../../core/graph-index.js`: _ради побочного действия_

**Содержит:** `generateBetweennessContent`, `generateClosenessContent`, `generateDegreeContent`, `generateEigenvectorContent`, `generateLocalCohesionContent`, `generateOverviewContent`, `generatePageRankContent`, `generateRichClubContent`, `generateWeightedClusteringContent`

### `modules/stats/views/philosopher.js`

Строк 171.

**Вывозит:** `generatePhilosopherInterdisciplinaryContent`, `generatePhilosopherProfileContent`, `generatePhilosopherReachContent`, `generatePhilosopherSystematicContent`

**Ввозит:**

- из `../../core/ns.js`: `DATA`, `MET`
- из `../../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../../metrics/philosopher.js`: `philosopherProfile`
- из `../results.js`: `generateMetricDescriptionBlock`, `rankKeep`
- из `./philosophical.js`: `influenceScopeSwitcher`
- из `../../core/graph-index.js`: _ради побочного действия_

**Содержит:** `generatePhilosopherInterdisciplinaryContent`, `generatePhilosopherProfileContent`, `generatePhilosopherReachContent`, `generatePhilosopherSystematicContent`

### `modules/stats/views/philosophical.js`

Строк 474.

**Вывозит:** `generateCoherenceContent`, `generateCriticalPowerContent`, `generateDialogicalContent`, `generateFoundationalContent`, `generateInfluenceContent`, `generateParadigmShiftContent`, `generateProblemGenerationContent`, `generateRevolutionaryContent`, `generateSyntheticContent`, `generateTensionContent`, `influenceScopeSwitcher`, `setInfluenceScope`

**Ввозит:**

- из `../../core/ns.js`: `DATA`, `MET`, `S`
- из `../../core/events.js`: `emit`
- из `../../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../../metrics/philosophical.js`: `INFLUENCE_SCOPE_LABELS`, `invalidateInfluenceIndexCache`
- из `../../metrics/rankings.js`: `invalidateGeneratePhilosopherRankingsCache`
- из `../results.js`: `generateMetricResults`, `rankKeep`
- из `../../util/html.js`: `withoutFootnotes`
- из `../../core/graph-index.js`: _ради побочного действия_

**Содержит:** `generateCoherenceContent`, `generateCriticalPowerContent`, `generateDialogicalContent`, `generateFoundationalContent`, `generateInfluenceContent`, `generateParadigmShiftContent`, `generateProblemGenerationContent`, `generateRevolutionaryContent`, `generateSyntheticContent`, `generateTensionContent`, `influenceScopeSwitcher`, `setInfluenceScope`

### `modules/stats/views/rankings.js`

Строк 141.

**Вывозит:** `generateConceptRankingsContent`, `generatePhilosopherRankingsContent`

**Ввозит:**

- из `../../core/ns.js`: `DATA`, `S`
- из `../../metrics/link-indexes.js`: `initializePhilosophyMetrics`
- из `../../metrics/rankings.js`: `generatePhilosopherRankings`, `generateRankings`
- из `../results.js`: `generateMetricDescriptionBlock`
- из `./philosophical.js`: `influenceScopeSwitcher`

**Содержит:** `generateConceptRankingsContent`, `generatePhilosopherRankingsContent`

### `modules/ui/about.js`

Строк 102.

**Вывозит:** `closeAboutModal`, `onAboutBackdropClick`, `openAboutModal`

**Ввозит:**

- из `../core/ns.js`: `DATA`

**Содержит:** `buildAboutText`, `closeAboutModal`, `onAboutBackdropClick`, `openAboutModal`

### `modules/ui/actions-byname.js`

Строк 20.

**Вывозит:** _ничего_

**Ввозит:**

- из `./actions.js`: `registerActions`
- из `../modal/persist.js`: `deleteConcept`, `deleteConnection`, `deletePhilosopher`, `saveConceptData`, `saveConnectionData`, `savePhilosopherData`

**Содержит:** `BY_NAME`, `callByName`

### `modules/ui/actions-dyn.js`

Строк 187.

**Вывозит:** _ничего_

**Ввозит:**

- из `./actions.js`: `registerActions`
- из `../core/ns.js`: `DATA`, `S`
- из `../graph/graph-data.js`: `findConnection`
- из `../graph/graph-selection.js`: `cancelGraphSelection`
- из `../metrics/format.js`: `toggleMetricValueMode`
- из `../modal/auth.js`: `authLogout`, `closeAuthModal`, `openAuthModal`, `submitAuth`
- из `../modal/commits.js`: `applyRelayout`, `askLayoutRevert`, `cancelLayoutRevert`, `doLayoutRevert`, `planRelayout`
- из `../modal/concept-view.js`: `computeSimilarNetworkColumn`, `forceSimilarColumn`
- из `../modal/connection-edit.js`: `createNewConceptForPhilosopher`, `createNewConnectionForConcept`, `onConnTypeChange`, `selectConnectionEditConcept`, `swapConnectionConcepts`
- из `../modal/connection-view.js`: `handleConnectionViewSearch`, `selectConnectionViewConcept`, `toggleConnectionSearchSection`
- из `../modal/core.js`: `closeUniversalModal`, `openUniversalModal`, `popModalState`, `toggleModalMode`
- из `../modal/descriptions.js`: `toggleAllConnectionDescriptions`, `toggleAllPhilosopherConceptDescriptions`, `toggleAllPhilosopherConnectionDescriptions`, `toggleConnectionDescription`, `togglePhilosopherConceptDescription`, `toggleSubsection`
- из `../modal/edit-forms.js`: `syncPhilColorFromPicker`, `updatePhilColorSample`
- из `../modal/entry.js`: `gotoNodeFromModal`, `openConceptById`, `openEditConceptModal`, `openEditConnectionModal`, `showAllConcepts`, `showPhilosopherDetailModal`
- из `../modal/forms.js`: `insertFootnote`, `refreshFootnoteRows`, `refreshProvenanceField`, `removeFootnote`
- из `../modal/history.js`: `revertEntityToVersion`, `toggleEntityHistory`
- из `../modal/persist.js`: `deleteConcept`, `deleteConnection`
- из `../modal/profile-concept.js`: `closeConceptProfileModal`, `showConceptProfileModal`, `toggleProfileOrder`
- из `../modal/profile-philosopher.js`: `closePhilosopherProfileModal`, `showPhilosopherProfileModal`
- из `../modal/search.js`: `clearModalSearch`, `handleModalSearch`
- из `../modal/security.js`: `confirmMfaEnroll`, `openSecurityModal`, `refreshSecurityDone`, `startMfaEnroll`
- из `../modal/selection-list.js`: `openSelectionLink`, `selectionListMore`, `setSelectionProvenance`, `toggleSelectionBlock`, `toggleSelectionBodies`, `toggleSelectionBody`
- из `../paths/path-descriptions.js`: `showPathDescriptionsModal`, `togglePathNodesDescriptions`
- из `../paths/path-ui.js`: `clearPathHighlight`, `handlePathArrowHover`
- из `../render/metric-visualization.js`: `toggleMetricVisualization`
- из `../render/selection.js`: `highlightNodeById`
- из `../render/similarity-overlay.js`: `clearSimilarityOverlay`, `setSimilarityLinks`, `showSimilarityOverlay`
- из `../stats/modal.js`: `openStatsModal`, `switchStatsView`
- из `../stats/observations.js`: `deleteObservation`, `pickObservation`, `saveObservation`
- из `../stats/results.js`: `toggleMetricDetails`, `toggleMetricLayout`
- из `../stats/run.js`: `calculateMetricFromModal`
- из `../stats/views/comparison.js`: `computeComparisonNetwork`, `openPairInComparison`, `openPhilosopherPair`, `renderClosestPairs`, `renderPhilosopherComparison`, `renderPhilosopherPairs`
- из `../stats/views/philosophical.js`: `setInfluenceScope`
- из `./legend.js`: `onlyTradition`, `resetTradition`, `togglePhilosopher`, `toggleRelation`, `toggleRubric`, `toggleTradition`
- из `./search-legend.js`: `selectSearchResult`
- из `./search-link.js`: `highlightLinkOnGraph`, `pickLinkEnd`
- из `./search-philosopher.js`: `clearPhilosopherSearch`, `handlePhilosopherSearch`, `pickPhilosopherFromSearch`, `selectPhilosopherResult`
- из `../widgets/custom-select.js`: `filterCustomSelect`, `selectCustomOption`, `showCustomSelectDropdown`

**Содержит:** _только исполняемый код_

### `modules/ui/actions-static.js`

Строк 140.

**Вывозит:** _ничего_

**Ввозит:**

- из `./actions.js`: `registerActions`
- из `../data/save.js`: `downloadData`, `saveToFolder`
- из `../filters/beyond-filter.js`: `resetBeyondFilter`
- из `../metrics/scope.js`: `handleMetricsScopeChange`
- из `../modal/commits.js`: `closeCommitsPanel`, `openCommitsPanel`, `switchCommitTab`
- из `../modal/conflict.js`: `closeConflictModal`, `rebuildOverCurrent`
- из `../modal/core.js`: `closeUniversalModal`
- из `../modal/profile-concept.js`: `closeConceptProfileModal`
- из `../modal/profile-philosopher.js`: `closePhilosopherProfileModal`
- из `../modal/selection-list.js`: `closeSelectionListModal`, `openSelectionListModal`
- из `../modal/users.js`: `closeUsersPanel`, `openUsersPanel`
- из `../paths/path-descriptions.js`: `closePathDescriptionsModal`
- из `../paths/path-ui.js`: `findAndShowPath`
- из `../render/grouping.js`: `toggleGrouping`
- из `../render/metric-visualization.js`: `resetNodeSizes`
- из `../render/simulation.js`: `centerGraph`, `resetSimulation`, `toggleSimulationFreeze`
- из `../stats/modal.js`: `closeStatsModal`, `handleStatsParameterChange`, `openStatsModal`, `switchStatsView`
- из `./about.js`: `closeAboutModal`, `onAboutBackdropClick`, `openAboutModal`
- из `./export.js`: `exportToPNG`, `exportToSVG`
- из `./legend.js`: `changeFilterMode`, `deselectAllPhilosophers`, `deselectAllRelations`, `deselectAllRubrics`, `deselectAllTraditions`, `selectAllPhilosophers`, `selectAllRelations`, `selectAllRubrics`, `selectAllTraditions`, `toggleSection`, `toggleUniformLinkWidth`
- из `./notifications.js`: `markAllNotificationsRead`, `toggleNotifyPanel`
- из `./panels.js`: `togglePanel`
- из `./search-legend.js`: `clearLegendSearch`, `handleLegendSearch`, `setSearchKind`, `toggleLegendSearch`
- из `./search-link.js`: `handleLegendLinkSearch`, `openLegendLinkSearch`
- из `./search-philosopher.js`: `clearLegendPhilSearch`, `handleLegendPhilSearch`
- из `../widgets/custom-select.js`: `filterCustomSelect`, `showCustomSelectDropdown`

**Содержит:** _только исполняемый код_

### `modules/ui/actions.js`

Строк 27.

**Вывозит:** `actionNames`, `registerActions`, `runAction`

**Ввозит:** _ничего_

**Содержит:** `ACTIONS`, `actionNames`, `registerActions`, `runAction`

### `modules/ui/delegation.js`

Строк 70.

**Вывозит:** `installDelegation`

**Ввозит:**

- из `./actions.js`: `runAction`

**Содержит:** `BOUNDS`, `EVENTS`, `installDelegation`, `withEventSwap`

### `modules/ui/export.js`

Строк 138.

**Вывозит:** `exportToPNG`, `exportToSVG`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/link-facts.js`: `isReflexiveLink`, `isSymmetricLink`
- из `../core/long-task.js`: `showTemporaryMessage`
- из `../core/visibility.js`: `isLinkVisible`, `isNodeVisible`
- из `../render/canvas-core.js`: `renderState`
- из `../render/draw-link.js`: `CONTRADICTION_DASH`, `linkDrawAlpha`, `linkDrawWidth`, `linkVisualState`
- из `../render/geometry.js`: `linkShape`
- из `../render/render-state.js`: `hasNodeClass`, `nodeEdgeWidth`, `nodeLabelDy`, `nodeRadius`
- из `../render/scene.js`: `DRAW_ORDER`, `renderScene`
- из `../state/render.js`: `selectedNodes`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `exportToPNG`, `exportToSVG`

### `modules/ui/hint.js`

Строк 60.

**Вывозит:** `installHintOnClick`, `installHintOnScroll`, `installHintOut`, `installHintOver`

**Ввозит:**

- из `../core/ns.js`: `S`

**Содержит:** `S.tooltipTimeout`, `hideHint`, `hintBox`, `installHintOnClick`, `installHintOnScroll`, `installHintOut`, `installHintOver`, `showHint`

### `modules/ui/legend.js`

Строк 392.

**Вывозит:** `changeFilterMode`, `deselectAllPhilosophers`, `deselectAllRelations`, `deselectAllRubrics`, `deselectAllTraditions`, `initFilters`, `markChosenInLegend`, `onlyTradition`, `resetTradition`, `selectAllPhilosophers`, `selectAllRelations`, `selectAllRubrics`, `selectAllTraditions`, `syncLegendDirectionToggle`, `syncLegendWeightsToggle`, `syncPhilosopherCheckboxes`, `syncTraditionRows`, `togglePhilosopher`, `toggleRelation`, `toggleRubric`, `toggleSection`, `toggleTradition`, `toggleUniformLinkWidth`, `traditionMembers`, `updateFilterStats`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/relation-types.js`: `relationHint`
- из `../filters/filters.js`: `applyFilters`
- из `../render/canvas-core.js`: `renderState`
- из `../render/d3-layer.js`: `updateArrows`
- из `../state/filters.js`: `chosenPhilosophers`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `WITHOUT_TRADITION`, `changeFilterMode`, `deselectAllPhilosophers`, `deselectAllRelations`, `deselectAllRubrics`, `deselectAllTraditions`, `initFilters`, `legendDirectionToggle`, `legendWeightsToggle`, `markChosenInLegend`, `onlyTradition`, `resetTradition`, `selectAllPhilosophers`, `selectAllRelations`, `selectAllRubrics`, `selectAllTraditions`, `syncLegendDirectionToggle`, `syncLegendWeightsToggle`, `syncPhilosopherCheckboxes`, `syncTraditionRows`, `togglePhilosopher`, `toggleRelation`, `toggleRubric`, `toggleSection`, `toggleTradition`, `toggleUniformLinkWidth`, `traditionMembers`, `updateFilterStats`, `updateProvenanceCoverage`

### `modules/ui/link-state.js`

Строк 282.

**Вывозит:** `_linkMissed`, `applyLinkState`, `currentLinkState`, `hashToLinkState`, `initLinkState`, `linkStateToHash`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/events.js`: `subscribe`
- из `../core/graph-index.js`: `conceptById`
- из `../core/long-task.js`: `showTemporaryMessage`
- из `../filters/filters.js`: `applyFiltersImmediate`
- из `../metrics/scope.js`: `handleMetricsScopeChange`
- из `../metrics/similarity-concepts.js`: `networkSimilarityData`
- из `../modal/context.js`: `ModalContext`
- из `../modal/core.js`: `openUniversalModal`
- из `../modal/entry.js`: `openConceptById`
- из `../paths/path-ui.js`: `findAndShowPath`
- из `../render/similarity-overlay.js`: `setSimilarityLinks`, `showSimilarityOverlay`
- из `../stats/modal.js`: `handleStatsParameterChange`, `openStatsModal`, `switchStatsView`
- из `../stats/views/comparison.js`: `renderComparison`
- из `./legend.js`: `changeFilterMode`, `syncPhilosopherCheckboxes`
- из `../widgets/custom-select.js`: `selectCustomOption`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `LINK_KEYS`, `_linkApplying`, `_linkLastHash`, `_linkMissed`, `applyLinkState`, `currentLinkState`, `excludedList`, `hashToLinkState`, `initLinkState`, `linkStateToHash`, `philosopherIdByName`, `philosopherNameById`, `syncLinkHash`

### `modules/ui/notifications.js`

Строк 103.

**Вывозит:** `loadNotifications`, `markAllNotificationsRead`, `markNotificationRead`, `notifyItems`, `refreshUnread`, `renderBell`, `toggleNotifyPanel`, `unreadCount`

**Ввозит:**

- из `../core/api.js`: `api`, `serverMode`
- из `../core/session.js`: `authSession`
- из `../util/html.js`: `escapeAttr`

**Содержит:** `loadNotifications`, `markAllNotificationsRead`, `markNotificationRead`, `notifyItems`, `notifyWords`, `refreshUnread`, `renderBell`, `renderNotifyList`, `toggleNotifyPanel`, `unreadCount`

### `modules/ui/panels.js`

Строк 40.

**Вывозит:** `restorePanelStates`, `togglePanel`

**Ввозит:** _ничего_

**Содержит:** `restorePanelStates`, `togglePanel`

### `modules/ui/search-legend.js`

Строк 141.

**Вывозит:** `clearLegendSearch`, `handleLegendSearch`, `installLegendSearchDismiss`, `selectSearchResult`, `setSearchKind`, `toggleLegendSearch`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/graph-index.js`: `conceptById`
- из `../core/long-task.js`: `showTemporaryMessage`
- из `../core/search.js`: `displaySearchResults`, `pickConcepts`
- из `../core/visibility.js`: `isNodeVisible`
- из `../filters/beyond-filter.js`: `updateFilterNote`
- из `../filters/filters.js`: `applyFiltersImmediate`
- из `../modal/entry.js`: `showDetailModal`
- из `../modal/search.js`: `clearModalSearch`
- из `../render/canvas-core.js`: `gfxSvg`
- из `../render/d3-layer.js`: `gfxZoom`
- из `../render/selection.js`: `highlightConnected`
- из `../state/filters.js`: `pinnedDespiteFilter`, `pinnedVisibleNodes`
- из `../state/render.js`: `selectedNodes`
- из `./search-link.js`: `clearLinkSearch`
- из `./search-philosopher.js`: `clearLegendPhilSearch`

**Содержит:** `clearLegendSearch`, `handleLegendSearch`, `installLegendSearchDismiss`, `searchKind`, `selectSearchResult`, `setSearchKind`, `toggleLegendSearch`

### `modules/ui/search-link.js`

Строк 135.

**Вывозит:** `clearLinkSearch`, `handleLegendLinkSearch`, `highlightLinkOnGraph`, `openLegendLinkSearch`, `pickLinkEnd`

**Ввозит:**

- из `../core/ns.js`: `DATA`, `S`
- из `../core/graph-index.js`: `conceptById`
- из `../core/link-facts.js`: `directionMark`
- из `../core/search.js`: `emptyList`, `pickConcepts`, `rowInner`
- из `../render/canvas-core.js`: `gfxSvg`
- из `../render/d3-layer.js`: `gfxZoom`
- из `../render/loop.js`: `requestDraw`
- из `../render/selection.js`: `highlightCombined`
- из `../state/render.js`: `selectedEdges`, `selectedNodes`
- из `../util/html.js`: `scrollToPickedRow`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `clearLinkSearch`, `handleLegendLinkSearch`, `highlightLinkOnGraph`, `linkSearch`, `openLegendLinkSearch`, `pickLinkEnd`, `showFoundLinks`

### `modules/ui/search-philosopher.js`

Строк 98.

**Вывозит:** `clearLegendPhilSearch`, `clearPhilosopherSearch`, `handleLegendPhilSearch`, `handlePhilosopherSearch`, `pickPhilosopherFromSearch`, `selectPhilosopherResult`

**Ввозит:**

- из `../core/ns.js`: `DATA`
- из `../core/graph-index.js`: `comparePhilosophers`
- из `../core/search.js`: `emptyList`
- из `../modal/core.js`: `openUniversalModal`
- из `../render/selection.js`: `highlightPhilosopherOnGraph`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `clearLegendPhilSearch`, `clearPhilosopherSearch`, `handleLegendPhilSearch`, `handlePhilosopherSearch`, `pickPhilosopherFromSearch`, `pickPhilosophers`, `selectPhilosopherResult`

### `modules/util/color.js`

Строк 23.

**Вывозит:** `getContrastColor`

**Ввозит:** _ничего_

**Содержит:** `getContrastColor`

### `modules/util/html.js`

Строк 95.

**Вывозит:** `FOOTNOTE_LABELS`, `FOOTNOTE_STATE_ORDER`, `escapeAttr`, `footnoteOrder`, `footnotedText`, `footnotesBlock`, `liveProgressHtml`, `provenanceBlock`, `scrollToPickedRow`, `updateLiveProgress`, `withoutFootnotes`

**Ввозит:** _ничего_

**Содержит:** `FOOTNOTE_LABELS`, `FOOTNOTE_MARK_SOURCE`, `FOOTNOTE_STATE_ORDER`, `escapeAttr`, `footnoteOrder`, `footnotedText`, `footnotesBlock`, `liveProgressHtml`, `provenanceBlock`, `scrollToPickedRow`, `updateLiveProgress`, `withoutFootnotes`

### `modules/util/philosopher-label.js`

Строк 40.

**Вывозит:** `formatBirthYear`, `labelWithAuthor`, `philosopherBirth`, `philosopherYears`, `sortPhilosophersByBirth`

**Ввозит:**

- из `../core/ns.js`: `DATA`
- из `../core/graph-index.js`: `comparePhilosophers`, `philosopherByName`
- из `../core/graph-index.js`: _ради побочного действия_

**Содержит:** `_ambiguousLabels`, `ambiguousLabels`, `formatBirthYear`, `labelWithAuthor`, `philosopherBirth`, `philosopherYears`, `sortPhilosophersByBirth`

### `modules/util/ru.js`

Строк 49.

**Вывозит:** `conjugateVerb`, `declinePhilosopher`, `pluralRu`

**Ввозит:** _ничего_

**Содержит:** `conjugateVerb`, `declinePhilosopher`, `pluralRu`

### `modules/widgets/custom-select.js`

Строк 103.

**Вывозит:** `filterCustomSelect`, `initializeCustomSelects`, `selectCustomOption`, `showCustomSelectDropdown`

**Ввозит:**

- из `../core/ns.js`: `S`
- из `../core/events.js`: `emit`
- из `../core/graph-index.js`: `conceptById`
- из `../core/search.js`: `emptyList`, `pickConcepts`, `rowInner`
- из `../util/html.js`: `scrollToPickedRow`

**Содержит:** `filterCustomSelect`, `initializeCustomSelects`, `pickedConceptOf`, `populateCustomSelect`, `selectCustomOption`, `showCustomSelectDropdown`