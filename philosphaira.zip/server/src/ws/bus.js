// ШИНА МЕЖДУ УЗЛАМИ.
//
// Соединения живут в памяти ТОГО процесса, который их принял. При двух
// работниках уведомление, положенное одним, не дойдёт до сокета, висящего
// на другом, — если между ними нет шины. В первой редакции документа Redis
// стоял в рекомендациях по развёртыванию, а в коде был Map в памяти одного
// процесса: половина уведомлений не дошла бы, и никто бы не понял почему.
//
// Здесь шина — LISTEN/NOTIFY самого Postgres. Довод простой: база уже есть,
// а второе хранилище — это второе, что надо поднимать, стеречь и чинить.
// Ограничение известно: полезная нагрузка NOTIFY до 8000 байт, поэтому по
// шине идёт ИЗВЕЩЕНИЕ, а не само уведомление — узел добирает его из базы.

import pg from 'pg';

export const CHANNEL = 'philos_ws';

export async function publish(client, notice) {
  await client.query(`SELECT pg_notify($1, $2)`,
    [CHANNEL, JSON.stringify(notice)]);
}

/**
 * Подписка. Держит ОТДЕЛЬНОЕ соединение: слушающий клиент занят и в пул
 * не возвращается — иначе LISTEN потеряется вместе с соединением.
 */
export async function subscribe(connectionString, onNotice) {
  const client = new pg.Client({ connectionString: connectionString });
  await client.connect();
  await client.query(`LISTEN ${CHANNEL}`);
  client.on('notification', message => {
    let result;
    // Кривое извещение не роняет узел: шина — вход извне, пусть и свой.
    try { result = JSON.parse(message.payload); } catch { return; }
    try { onNotice(result); } catch { /* обработчик сам себе судья */ }
  });
  return {
    client,
    async close() {
      try { await client.query(`UNLISTEN ${CHANNEL}`); } catch { /* уже мертво */ }
      await client.end().catch(() => {});
    },
  };
}
