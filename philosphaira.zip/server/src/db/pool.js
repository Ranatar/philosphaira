// Пул соединений. Единственное место, где заводится связь с базой.
//
// Правило, из которого всё следует: rows[0] НЕ ПОКИДАЕТ server/src/db/.
// Половина дефектов первой редакции росла из того, что строка базы гуляла
// по службам как доменный объект: verifyToken клал в req.user строку со
// змеиными именами, а проверка прав спрашивала верблюжьи — и ответ не
// зависел от состояния пользователя вовсе. Стережёт проба rows_stay_in_db.

import pg from 'pg';

const { Pool, types } = pg;

// BIGINT (int8) приходит строкой, чтобы не терять точность за пределами
// 2^53. Нам такие величины нужны числами (ключи журнала, счётчики), и
// молчаливое «17" вместо 17» — источник сравнений, которые не сходятся.
// Точность в этих полях заведомо в пределах безопасной.
types.setTypeParser(20, v => (v === null ? null : Number(v)));

export function createPool(connectionString = process.env.DATABASE_URL) {
  if (!connectionString) {
    throw new Error(
      'DATABASE_URL не задан. Умолчания здесь нет нарочно: молча уйти ' +
      'не в ту базу хуже, чем не запуститься.');
  }
  return new Pool({
    connectionString: connectionString,
    max: Number(process.env.PG_POOL_MAX || 10),
    idleTimeoutMillis: 30_000,
    // Запрос, повисший навсегда, держит соединение и не даёт ничего понять.
    statement_timeout: Number(process.env.PG_STATEMENT_TIMEOUT || 15_000),
  });
}

export const pool = process.env.DATABASE_URL ? createPool() : null;
