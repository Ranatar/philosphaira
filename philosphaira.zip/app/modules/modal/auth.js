// Сгенерировано из philosophy_graph.html — правки вносить ТУДА, не сюда.
import { S } from '../core/ns.js';
import { api, detectServerMode, serverMode } from '../core/api.js';
import { emit } from '../core/events.js';
import { AUTH_ADMIN, authAccounts, setSessionUser } from '../core/session.js';
import { reportSubmit } from '../data/backend.js';
import { connectLive, disconnectLive, pullGraphSince } from '../data/remote.js';
import { ModalContext } from './context.js';
import { toggleModalMode } from './core.js';
import { refreshEditHints, refreshOpenModalToolbar, renderAuthControls } from './edit-rights.js';

S.authModalKind = 'login';

function authModalEl() { return document.getElementById('authModal'); }

function openAuthModal(kind) {
      S.authModalKind = kind;
      const el = authModalEl();
      if (!el) return;
      const title = kind === 'register' ? '📝 Регистрация' : '🔑 Вход';
      const act   = kind === 'register' ? 'Зарегистрироваться' : 'Войти';
      el.innerHTML =
        '<h3>' + title + '</h3>'
      + '<div class="auth-field"><label for="authLogin">Логин или почта</label>'
      + '<input type="text" id="authLogin" autocomplete="off"></div>'
      + '<div class="auth-field"><label for="authPassword">Пароль</label>'
      + '<input type="password" id="authPassword" autocomplete="off"></div>'
      + '<div class="auth-error" id="authError"></div>'
      + '<div class="auth-actions">'
      + '<button data-act-click="close-auth-modal">Отмена</button>'
      + '<button class="primary" data-act-click="submit-auth">' + act + '</button>'
      + '</div>';
      el.classList.add('show');
      const overlay = document.getElementById('modalOverlay');
      if (overlay) overlay.classList.add('show');
      const inp = document.getElementById('authLogin');
      if (inp) {
        inp.focus();
        // Enter в любом поле равносилен нажатию главной кнопки.
        el.querySelectorAll('input').forEach(f => f.addEventListener('keydown', e => {
          if (e.key === 'Enter') { e.preventDefault(); submitAuth(); }
        }));
      }
    }

function closeAuthModal() {
      const el = authModalEl();
      if (el) { el.classList.remove('show'); el.innerHTML = ''; }
      const overlay = document.getElementById('modalOverlay');
      const universal = document.getElementById('universalModal');
      const stats = document.getElementById('statsModal');
      const otherOpen = (universal && universal.classList.contains('show'))
                     || (stats && stats.classList.contains('show'));
      if (overlay && !otherOpen) overlay.classList.remove('show');
    }

function authError(text) {
      const el = document.getElementById('authError');
      if (el) el.textContent = text;
    }

function showAuthNotice(title, bodyHtml) {
      S.authModalKind = 'notice';
      const el = authModalEl();
      if (!el) return;
      el.innerHTML =
        '<h3>' + title + '</h3>'
      + '<div class="auth-notice">' + bodyHtml + '</div>'
      + '<div class="auth-actions" style="margin-top:16px;">'
      + '<button class="primary" data-act-click="close-auth-modal">Понятно</button>'
      + '</div>';
      el.classList.add('show');
      const overlay = document.getElementById('modalOverlay');
      if (overlay) overlay.classList.add('show');
    }

function authNoticeMember(login) {
      showAuthNotice('Здравствуйте, ' + login,
        'Теперь можно составлять и отправлять предложения по правке графа.'
      + '<p><em>Оговорка: сам ход отправки ещё не сделан — он появится '
      + 'вместе с серверной частью. Пока это только устройство прав.</em></p>');
    }

function authNoticeAdmin() {
      showAuthNotice('Правка открыта',
        'Теперь граф можно править. Порядок такой:'
      + '<ul>'
      + '<li>Shift + клик по концепции — правка концепции;</li>'
      + '<li>Shift + клик по двум концепциям подряд — правка связи между ними;</li>'
      + '<li>Shift + клик по связи — правка этой связи;</li>'
      + '<li>Shift + клик по пустому месту полотна — новая концепция;</li>'
      + '<li>Shift + клик по заголовку «Философы:» — новый философ;</li>'
      + '<li>Shift + клик по философу в легенде — правка философа;</li>'
      + '<li>кнопка «✏️ Редактировать» в окне философа, концепции и связи.</li>'
      + '</ul>');
    }

async function submitAuth() {
      if (logoutInFlight) await logoutInFlight;   // см. authLogout
      const login = (document.getElementById('authLogin') || {}).value || '';
      const pass  = (document.getElementById('authPassword') || {}).value || '';
      if (!login.trim() || !pass) { authError('Заполните логин и пароль'); return; }
      const l = login.trim();

      if (serverMode && S.authModalKind === 'mfa') {
        const reply = await api('/api/auth/mfa', { метод: 'POST', тело: { code: pass } });
        if (!reply.годно) { authError('Код не сошёлся'); return; }
        await detectServerMode();
        await pullGraphSince();
        connectLive();
        // Как и обычный вход: колокол и «Замеры» перепроверяются по событию.
        emit('session-changed');
        renderAuthControls();
        refreshEditHints();
        refreshOpenModalToolbar();
        closeAuthModal();
        return;
      }

      if (S.authModalKind === 'register') {
        // Логин admin занят: он сверяется отдельно и регистрации не требует.
        if (l === AUTH_ADMIN.login || authAccounts.has(l)) {
          authError('Такой логин уже зарегистрирован'); return;
        }
        authAccounts.set(l, pass);
        setSessionUser({ login: l, role: 'member' });
        renderAuthControls();
        refreshEditHints();
        authNoticeMember(l);
        return;
      }

      // СЕРВЕРНЫЙ РЕЖИМ. Пароли, их требования и права — забота сервера;
      // страница только спрашивает и показывает. Местная ветка ниже
      // остаётся нетронутой: без сервера всё как прежде.
      if (serverMode) {
        const reply = await api('/api/auth/login',
          // ПОЛЕ ЗОВЁТСЯ `login`, А НЕ `email`. Подпись поля обещала логин,
          // а значение уходило как почта — и сервер искал только по почте.
          // Войти именем было нельзя, хотя findByUsername в db/users.js
          // написана. Расхождение подписи со службой нашёл человек: ввёл имя
          // администратора из примера в инструкции и не смог войти.
          { метод: 'POST', тело: { login: l, password: pass } });
        if (!reply.годно) {
          authError((reply.тело && reply.тело.error && reply.тело.error.message)
            || 'Не удалось войти');
          return;
        }
        if (reply.тело.data && reply.тело.data.ждётКода) {
          // Второй шаг: сессия пока частичная и прав не даёт.
          authError('Введите одноразовый код в поле пароля и нажмите «Войти» ещё раз');
          S.authModalKind = 'mfa';
          return;
        }
        await detectServerMode();          // права берём у сервера, а не гадаем
        // ЖИВОЕ СОЕДИНЕНИЕ ПЕРЕОТКРЫВАЕТСЯ. При запуске страница ещё гость,
        // а гостю сокета не дают — рукопожатие требует сеанса. Первый
        // набросок открывал соединение только на запуске, и оно НИКОГДА не
        // появлялось у тех, кто вошёл после загрузки, то есть у всех.
        // Проба показала это тем, что чужая правка не доходила.
        await pullGraphSince();
        connectLive();
        // Через ШИНУ: колокол живёт на шестом этаже, вход — на пятом, и
        // ввозить снизу вверх дерево не даёт. Прибор строения показал это
        // ребро сразу, как только оно появилось.
        emit('session-changed');
        renderAuthControls();
        refreshEditHints();
        refreshOpenModalToolbar();
        closeAuthModal();
        return;
      }

      // Вход. Требований к паролю нет — это решено сознательно; когда
      // появится сервер, требования станут его заботой.
      //
      // Сообщения РАЗДЕЛЬНЫЕ. На сервере так делать нельзя: раздельный
      // ответ выдаёт, какие логины существуют. Здесь список учётных
      // записей и так виден в коде страницы, скрывать нечего, а
      // раздельное сообщение вдвое понятнее.
      if (l === AUTH_ADMIN.login) {
        if (pass !== AUTH_ADMIN.password) { authError('Неверный пароль'); return; }
        setSessionUser({ login: l, role: 'admin' });
        renderAuthControls();
        refreshEditHints();
        refreshOpenModalToolbar();
        authNoticeAdmin();
        return;
      }
      if (!authAccounts.has(l)) { authError('Такой логин не зарегистрирован'); return; }
      if (authAccounts.get(l) !== pass) { authError('Неверный пароль'); return; }
      setSessionUser({ login: l, role: 'member' });
      renderAuthControls();
      refreshEditHints();
      authNoticeMember(l);
    }

let logoutInFlight = null;

function authLogout() {
      const modal = document.getElementById('universalModal');
      const open = modal && modal.classList.contains('show');
      const wasEdit = open && ModalContext.currentMode === 'edit';

      // Право уходит ПЕРВЫМ делом: что бы дальше ни случилось с открытой
      // формой, кнопка правки в перерисованном окне уже не появится.
      setSessionUser(null);
      renderAuthControls();
      refreshEditHints();

      // СЕРВЕРНЫЙ ЛАД: выход гасит СЕАНС, а не только вид. Прежде кнопка
      // снимала права на странице, а cookie оставался жив: сервер считал
      // человека вошедшим, сокет с личными извещениями не закрывался, и
      // перезагрузка возвращала его под той же записью (замер 26.09.2026 —
      // на общем компьютере «Выйти» не выходило). Теперь событие о смене
      // сеанса шлётся и при выходе: колокол гостя сервер больше не спрашивает.
      if (serverMode) {
        disconnectLive();
        // Ответ выхода ЧИСТИТ cookie сеанса. Придись он позже ответа нового
        // входа — стёр бы уже новый сеанс; поэтому вход ждёт этот обещанный
        // ответ (logoutInFlight), а не полагается на порядок доставки.
        logoutInFlight = api('/api/auth/logout', { метод: 'POST' }).then(reply => {
          logoutInFlight = null;
          if (!reply.годно) {
            reportSubmit('отказ', 'Сервер не подтвердил выход: сеанс может остаться открытым. '
              + 'Перезагрузите страницу и выйдите ещё раз.');
          }
        });
        emit('session-changed');
      }

      if (wasEdit) {
        // Через тот же ход, что и кнопка «👁️ Просмотр»: он спросит про
        // несохранённое. Если правщик откажется, окно останется в правке —
        // тогда снимаем с глаз только кнопку, не трогая набранного.
        toggleModalMode();
        if (ModalContext.currentMode === 'edit') {
          const btn = document.querySelector('.modal-toolbar-left .mode-switch-btn');
          if (btn) btn.remove();
        }
      } else if (open) {
        refreshOpenModalToolbar();
      }
    }

export { authLogout, closeAuthModal, openAuthModal, submitAuth };
