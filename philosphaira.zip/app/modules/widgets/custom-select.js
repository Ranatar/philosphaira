// Сгенерировано из philosophy_graph.html — правки вносить ТУДА, не сюда.
import { S } from '../core/ns.js';
import { emit } from '../core/events.js';
import { conceptById } from '../core/graph-index.js';
import { emptyList, pickConcepts, rowInner } from '../core/search.js';
import { scrollToPickedRow } from '../util/html.js';

function initializeCustomSelects() {
      // Инициализация выпадающих списков с полным списком узлов
      populateCustomSelect('source');
      populateCustomSelect('target');
      
      // П3: обработчик перечислял source и target поимённо и потому не знал
      // о списках, созданных позже — представление статистики рисуется
      // динамически. Теперь закрываются все, кроме того, внутри которого клик.
      document.addEventListener('click', function(event) {
        document.querySelectorAll('.custom-select-wrapper').forEach(wrapper => {
          if (!wrapper.contains(event.target)) {
            wrapper.querySelector('.custom-select-dropdown')?.classList.remove('show');
          }
        });
      });
    }

function pickedConceptOf(type) {
      if (type === 'source') return S.selectedSourceNode;
      if (type === 'target') return S.selectedTargetNode;
      if (type === 'cmpA')   return S._cmpA;
      if (type === 'cmpB')   return S._cmpB;
      return null;
    }

function populateCustomSelect(type, query = '') {
      const dropdown = document.getElementById(`${type}SelectDropdown`);
      if (!dropdown) return;

      // Тот же отбор и та же строка, что везде: прежде здесь список
      // выпадал весь, но без цветного кружка философа.
      const nodes = pickConcepts(query);
      const picked = pickedConceptOf(type);
      dropdown.innerHTML = nodes.length
        ? nodes.map(n => `
            <div class="concept-row${n.id === picked ? ' concept-row-picked' : ''}"
                 data-act-click="select-custom-option" data-a1="${type}" data-a2="${n.id}">
              ${rowInner(n)}
            </div>`).join('')
        : emptyList();
    }

function showCustomSelectDropdown(type) {
      const dropdown = document.getElementById(`${type}SelectDropdown`);
      const input = document.getElementById(`${type}SelectInput`);
      
      if (!dropdown || !input) return;
      
      // По фокусу — ВЕСЬ список, а не отбор по тексту поля.
      populateCustomSelect(type, '');
      dropdown.classList.add('show');
      scrollToPickedRow(dropdown);
      // Имя выбранного выделяется целиком: набор поверх него заменяет текст,
      // а не дописывается к нему.
      if (typeof input.select === 'function' && input.value) input.select();
    }

function filterCustomSelect(type, query) {
      const dropdown = document.getElementById(`${type}SelectDropdown`);
      
      if (!dropdown) return;
      
      populateCustomSelect(type, query);
      
      if (!dropdown.classList.contains('show')) {
        dropdown.classList.add('show');
      }
    }

function selectCustomOption(type, nodeId) {
      const node = conceptById.get(nodeId);
      if (!node) return;
      
      const input = document.getElementById(`${type}SelectInput`);
      const dropdown = document.getElementById(`${type}SelectDropdown`);
      
      if (input) {
        input.value = `${node.label} (${node.concept})`;
      }
      if (dropdown) {
        dropdown.classList.remove('show');
      }
      
      if (type === 'source') {
        S.selectedSourceNode = nodeId;
      } else if (type === 'target') {
        S.selectedTargetNode = nodeId;
      } else if (type === 'cmpA' || type === 'cmpB') {
        // П2: те же поля обслуживают сравнение концепций
        if (type === 'cmpA') S._cmpA = nodeId; else S._cmpB = nodeId;
        emit('comparison-refresh');
      }
    }

export { filterCustomSelect, initializeCustomSelects, selectCustomOption, showCustomSelectDropdown };
